/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Employee Service
 * 
 */
package com.capgemini.oirs.service;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.oirs.dao.EmployeeDao;
import com.capgemini.oirs.dao.IEmployeeDao;
import com.capgemini.oirs.dao.IRequisitionDAO;
import com.capgemini.oirs.dao.IRequisitionPoolDAO;
import com.capgemini.oirs.dao.RequisitionDAO;
import com.capgemini.oirs.dao.RequisitionPoolDAO;
import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.exceptions.OirsException;

public class EmployeeService implements IEmployeeService{

	IEmployeeDao employeeDao = new EmployeeDao();
	
	public boolean isValidName(String user_name) 
	{		// Validate Employee Name
		Pattern p = Pattern.compile("[a-zA-Z\\s]{1,25}");
		Matcher m = p.matcher(user_name);
		return m.matches();
	}
	
	@Override
	public boolean isValidExperience(String experience) {
		// Validate entered experience
		Pattern pattern = Pattern.compile("^[0-9]{1,2}$");
		Matcher m = pattern.matcher(experience);
		return m.matches();
	}


	@Override
	public boolean isValidUser(String emp_id) {
		// Validate Employee ID
		try {
			String x = employeeDao.getEmployeeId(emp_id);
			if(x==null)
				return false;
			else 
				return true;
		} catch (OirsException e) {
			System.err.println("Something went wrong while validating user ID");
		}
		return false;
	}
	
	

	@Override
	public boolean validatePassword(String emp_password,String password) throws OirsException 
	{
		
		//Check if password match
		if (password.equals(emp_password)) 
			return true;		
		else
			return false;
		
		
	}

	@Override
	public String getEmployeeType(String username) throws OirsException {
		//Retrieve the employee type
		String type;
		type = employeeDao.getEmployeeType(username);
		return type;
	}

	@Override
	public String getEmployeeName(String username) throws OirsException {
		//Retrieve the employee name
		String name;
		name = employeeDao.getEmployeeName(username);
		
		return name;
	}

	@Override
	public Employee getEmployee(String username) throws OirsException {
		//Retrieve the Employee bean object (initialized)
		Employee employee = null;
		employee = employeeDao.getEmployee(username);
		
		return employee;
	}

	@Override
	public boolean updatePassword(Employee employee) throws OirsException {
		//Update the password of the employee
		String old_password;
		String new_password1;
		String new_password2;
		boolean flag=false;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		System.out.println("\nEnter Old Password    : ");
		old_password = sc.nextLine();
		if(old_password.equals(employee.getPassword()))
		{
			System.out.println("Enter new password    : ");
			new_password1=sc.nextLine();
			System.out.println("Re-Enter new password :");
			new_password2=sc.nextLine();
			if(new_password1.equals(new_password2))
			{	
				Pattern p = Pattern.compile("^[a-zA-Z0-9]{8,16}$");
				Matcher m = p.matcher(new_password1);
				if (m.matches())
				{
					if(employeeDao.setEmployeePassword(employee.getEmployee_id(), new_password1)>0)
					{
						employee.setPassword(new_password1);
						flag=true;							
					}		
				}				
				else {
					System.out.println("Password must be of length [8-16] and must contain a character !!!");
				}
						
			}
			else 
			{
				System.out.println("Passwords do not match !!!!");
			}
		}
		else 
		{
			System.out.println("Username and Password does not match !!!");
		}
		
		return flag;
	}

	@Override
	public String[] getHierarchy(String username) throws OirsException {
		//Get the hierarchy of an employee
		return employeeDao.getHierarchy(username);
	}
	
	

	@Override
	public ArrayList<Employee> viewResourcePool() throws OirsException{
		// Retrieve Resource Pool table from DB

		ArrayList<Employee> employees = new ArrayList<Employee>();
		employees=employeeDao.viewResourcePool();
		return employees;
		
	}

	@Override
	public int updateProjectId(String requisitionId) throws OirsException {
		// Update Project ID by Requisition ID
		
		IRequisitionDAO requisitionDAO = new RequisitionDAO();
		IRequisitionPoolDAO requisitionPoolDAO = new RequisitionPoolDAO();
		
		String projectId = requisitionDAO.getProjectId(requisitionId);
		
		ArrayList<String> emp_ids = new ArrayList<String>();
		emp_ids = requisitionPoolDAO.getEmployeePool(requisitionId);
		
		return employeeDao.updateProjectId(projectId,emp_ids);
		
		
	}
	
	

}
