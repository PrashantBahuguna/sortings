/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Service Interface
 * 
 */
package com.capgemini.oirs.service;

import java.util.ArrayList;

import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public interface IRequisitionService {
	
	public abstract String generateRequisitionID () throws OirsException;
	public abstract Requisition displayRequisition (String requisitionId) throws OirsException;
	public abstract int raiseRequisition(Requisition requisition) throws OirsException;
	public abstract ArrayList<Requisition> displayRequisitionByRM(String rmId) throws OirsException;
	public abstract ArrayList<Requisition> displayAllRequisitions () throws OirsException;
	public abstract int undertakeRequisition(String requisition_id,String rmge_id) throws OirsException;
	public abstract ArrayList<Requisition> viewUndertakenRequisitions(String rmge_id) throws OirsException;
	public abstract int getResourcesRequired (String reqId) throws OirsException;
	public abstract int acceptRequisition(String requisitionId, String employee_id) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByStatus(String employee_id,String status) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByDomain(String employee_id,String domain) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsBySkill(String employee_id, String skill) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByProjectId(String employee_id,String projectId) throws OirsException;
	
	
	
}
