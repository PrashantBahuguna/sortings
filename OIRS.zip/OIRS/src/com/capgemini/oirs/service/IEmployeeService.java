/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Employee Service Interface 
 * 
 */
package com.capgemini.oirs.service;

import java.util.ArrayList;

import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.exceptions.OirsException;

public interface IEmployeeService {
	
	
	
	public abstract boolean validatePassword(String username,String password) throws OirsException;
	public abstract String getEmployeeType(String username) throws OirsException;
	public abstract String getEmployeeName(String username) throws OirsException;
	public abstract Employee getEmployee(String username) throws OirsException;
	public abstract boolean updatePassword(Employee employee) throws OirsException;
	public abstract String[] getHierarchy(String username) throws OirsException;
	public abstract ArrayList<Employee> viewResourcePool() throws OirsException;
	public abstract int updateProjectId(String requisitionId) throws OirsException;
	boolean isValidUser(String emp_id);
	boolean isValidExperience(String experience);

}
