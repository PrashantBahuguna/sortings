/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Pool Service 
 * 
 */
package com.capgemini.oirs.service;

import java.util.ArrayList;

import com.capgemini.oirs.dao.IRequisitionPoolDAO;
import com.capgemini.oirs.dao.RequisitionPoolDAO;
import com.capgemini.oirs.dto.RequisitionPool;
import com.capgemini.oirs.exceptions.OirsException;

public class RequisitionPoolService implements IRequisitionPoolService{

	IRequisitionPoolDAO requisitionPoolDAO = new RequisitionPoolDAO();
	
	@Override
	public int initRequisitionPool(ArrayList<String> emp_ids,String reqId) throws OirsException {
		int ret = requisitionPoolDAO.initRequisitionPool(emp_ids);
		ret += requisitionPoolDAO.setRequisitionIds(emp_ids,reqId);
		return ret;
	}

	@Override
	public ArrayList<RequisitionPool> viewRequisitionPool() throws OirsException {
		// Retrieve Requisition Pool table from the DB
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		requisitionPools=requisitionPoolDAO.viewRequisitionPool();
		return requisitionPools;
		
	}
	
	
	@Override
	public ArrayList<RequisitionPool> viewRequisitionPoolById(String req_id) throws OirsException {
		// Retrieve the Requisition Pool by Requisition ID
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		requisitionPools=requisitionPoolDAO.viewRequisitionPoolById(req_id);
		return requisitionPools;
		
	}

	@Override
	public int clearRequisitionPool(String requisitionId) throws OirsException {
		// Clear the Requisition Pool table in DB
		return requisitionPoolDAO.clearRequisitionPool(requisitionId);
	}

	

	

}
