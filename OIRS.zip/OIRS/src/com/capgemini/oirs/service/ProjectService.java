/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Project Service 
 * 
 */
package com.capgemini.oirs.service;

import com.capgemini.oirs.dao.IProjectDao;
import com.capgemini.oirs.dao.ProjectDAO;
import com.capgemini.oirs.exceptions.OirsException;

public class ProjectService implements IProjectService{

	IProjectDao projectDao = new ProjectDAO();
	
	@Override
	public int closeProject(String projectId) throws OirsException {
		// Close the project by project_ID
		
		return projectDao.closeProject(projectId);
		
	}

	@Override
	public boolean validateProject(String projectId){
		// Validate the Project ID from DB
		
		String value=null;
		try {
			value = projectDao.validateProject(projectId);
		} catch (OirsException e) {
			System.err.println(e.getMessage());
		}
		if(projectId.equals(value))
			return true;
		else
			return false;
		
	}

}
