/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Admin Service Class 
 * 
 */
package com.capgemini.oirs.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.oirs.dao.EmployeeDao;
import com.capgemini.oirs.dao.IEmployeeDao;
import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.dto.RequisitionPool;
import com.capgemini.oirs.exceptions.OirsException;

public class AdminService implements IAdminService{

	IEmployeeDao employeeDAO = new EmployeeDao();
	@Override
	public int addEmployee(Employee employee) throws OirsException {
		// Add employee bean to DB
		
		return employeeDAO.addEmployee(employee);
		
	}

	@Override
	public int deleteEmployee(String emp_id) throws OirsException {
		// Delete employee from DB by emp ID
		
		return employeeDAO.deleteEmployee(emp_id);
		
	}

	@Override
	public ArrayList<Employee> viewAllEmployees() throws OirsException {
		// Get all employees from DB and return the list
		ArrayList<Employee> employees = new ArrayList<Employee>();
		try {
			employees=employeeDAO.displayAllEmployee();
		} catch (SQLException e1) {
			throw new OirsException();
		}
		return employees;
		
	}

	@Override
	public int assignRole(String emp_id, String nEmp_type) throws OirsException {
		// Assign new role (nEmp_type) of given employee ID
		
		return employeeDAO.assignRole(emp_id,nEmp_type);
		
	}

	@Override
	public boolean validatePassword(String password) {
		// Validate password
		Pattern p = Pattern.compile("^[a-zA-Z0-9]{8,16}$");
		Matcher m = p.matcher(password);
		return m.matches();
		
	}
	
	public boolean isValidName(String user_name) 
	{		// Validate Name
		Pattern p = Pattern.compile("[a-zA-Z\\s]{1,25}");
		Matcher m = p.matcher(user_name);
		return m.matches();
	}


	@Override
	public boolean isValidUser(String emp_id) {
		// Validate EMPLOYEE ID
		try {
			String x = employeeDAO.getEmployeeId(emp_id);
			if(x==null)
				return false;
			else 
				return true;
		} catch (OirsException e) {
			System.err.println("Something went wrong while validating user ID");
		}
		return false;
	}

	@Override
	public boolean isValidExperience(String experience) {
		// Validate entered experience
		Pattern pattern = Pattern.compile("^[0-9]{1,2}$");
		Matcher m = pattern.matcher(experience);
		return m.matches();
	}

	
	
	
	
	
	

}
