/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Service Class
 * 
 */
package com.capgemini.oirs.service;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.oirs.dao.IRequisitionDAO;
import com.capgemini.oirs.dao.IRequisitionPoolDAO;
import com.capgemini.oirs.dao.RequisitionDAO;
import com.capgemini.oirs.dao.RequisitionPoolDAO;
import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public class RequisitionService implements IRequisitionService {
	
	Scanner scanner = new Scanner(System.in);
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy");  
	LocalDateTime date_now = LocalDateTime.now();  
	IRequisitionDAO requisitionDAO = new RequisitionDAO();
	Requisition requisition = new Requisition();
	
	@Override
	public String generateRequisitionID() throws OirsException {
		// Get auto generated Requisition ID from the DB
		int requisition_id = requisitionDAO.generateRequisitionID();
		String requisitionIdString = "RQ"+requisition_id;
		return requisitionIdString;
	}
	
	@Override
	public int raiseRequisition(Requisition requisition) throws OirsException 
	{	//Raise a requisition by sending requisition bean to DB
		
		
		if(requisitionDAO.raiseRequisition(requisition)>0)
			return 1;
		else 			
			return 0;
		
	}

	@Override
	public Requisition displayRequisition(String requisitionId)	throws OirsException 
	{	//Display the requisitions details by Requisition ID
		
		requisition = requisitionDAO.getRequisition(requisitionId);		
		return requisition;
	
	}

	@Override
	public ArrayList<Requisition> displayRequisitionByRM(String rmId) throws OirsException {
	//Display all requisitions under the RM ID
	
		ArrayList<Requisition> requisitions;		
		requisitions = requisitionDAO.getRequisitionByRM(rmId);		
		return requisitions;
		
	}

	@Override
	public ArrayList<Requisition> displayAllRequisitions() throws OirsException {
	//Display all the requisitions from the table and return the list
		
		ArrayList<Requisition> requisitions;
		requisitions = requisitionDAO.getAllRequisitions();
		return requisitions;
		
	}

	@Override
	public int undertakeRequisition(String requisition_id,String rmge_id) throws OirsException {
	//Undertake a requisition by sending requisition id and RMGE ID to the DB
		
		return requisitionDAO.undertakeRequisition(requisition_id,rmge_id);
	}

	@Override
	public ArrayList<Requisition> viewUndertakenRequisitions(String rmge_id) throws OirsException {
	//Get the list of Requisitions undertaken by a RMGE
		
		ArrayList<Requisition> requisitions;		
		requisitions = requisitionDAO.getUndertakenRequisitions(rmge_id);
		return requisitions;
		
	}

	@Override
	public int getResourcesRequired(String reqId) throws OirsException {
		// Get the resources required for a Requisition ID
		
		return requisitionDAO.getResourcesRequired(reqId);
	}

	@Override
	public int acceptRequisition(String requisitionId, String employee_id) throws OirsException {
		// Accept a requisition
		
		
		IRequisitionPoolDAO requisitionPoolDAO = new RequisitionPoolDAO();
		
		// Accept a requisition
		int ret =  requisitionDAO.acceptRequisition(requisitionId,employee_id);
		//Clear the requisition pool after accepting
		ret += requisitionPoolDAO.clearRequisitionPool(requisitionId);
		
		return ret;
		
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByStatus(String employee_id,String status) throws OirsException {
		// Display All Requisitions by Status of an Employee
		ArrayList<Requisition> requisitions ;
		requisitions = requisitionDAO.viewRequisitionsByStatus(employee_id,status);		
		return requisitions;
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByDomain(String employee_id, String domain)	throws OirsException {
		// Display All Requisitions by Domain of an Employee
		ArrayList<Requisition> requisitions ;
		requisitions=requisitionDAO.viewRequisitionsByDomain(employee_id, domain);
		return requisitions;
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsBySkill(String employee_id, String skill) throws OirsException {
		// Display All Requisitions by Skill of an Employee
		
		ArrayList<Requisition> requisitions ;
		requisitions=requisitionDAO.viewRequisitionsBySkill(employee_id, skill);
		return requisitions;
		
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByProjectId(String employee_id, String projectId) throws OirsException {
		// Display All Requisitions by Project ID of an Employee
		ArrayList<Requisition> requisitions ;
		requisitions=requisitionDAO.viewRequisitionsByProjectId(employee_id, projectId);
		return requisitions;
	}

	

}
