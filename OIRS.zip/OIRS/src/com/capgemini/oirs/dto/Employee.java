/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Employee Bean Class 
 * 
 */
package com.capgemini.oirs.dto;

/**
 * @author pbahugun
 *
 */
public class Employee {
	
	private String employee_id;
	private String password;
	private String name;
	private String project_id;
	private String skill;
	private String domain;
	private int experience;
	private String emp_type;
	/**
	 * 
	 */
	public Employee() {
		super();
	}
	/**
	 *Parameterized constructor
	 */
	public Employee(String employee_id, String password, String name, String project_id, String skill, String domain,
			int experience, String emp_type) 
	{
		super();
		this.employee_id = employee_id;
		this.password = password;
		this.name = name;
		this.project_id = project_id;
		this.skill = skill;
		this.domain = domain;
		this.experience = experience;
		this.emp_type = emp_type;
	}
	/**
	 * @return the employee_id
	 */
	public String getEmployee_id() {
		return employee_id;
	}
	/**
	 * @param employee_id the employee_id to set
	 */
	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the project_id
	 */
	public String getProject_id() {
		return project_id;
	}
	/**
	 * @param project_id the project_id to set
	 */
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	/**
	 * @return the skill
	 */
	public String getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(String skill) {
		this.skill = skill;
	}
	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}
	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}
	/**
	 * @return the experience
	 */
	public int getExperience() {
		return experience;
	}
	/**
	 * @param experience the experience to set
	 */
	public void setExperience(int experience) {
		this.experience = experience;
	}
	/**
	 * @return the emp_type
	 */
	public String getEmp_type() {
		return emp_type;
	}
	/**
	 * @param emp_type the emp_type to set
	 */
	public void setEmp_type(String emp_type) {
		this.emp_type = emp_type;
	}
	
	
}
