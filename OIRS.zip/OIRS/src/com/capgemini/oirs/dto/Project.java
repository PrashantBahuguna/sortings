/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Project DAO Interface 
 * 
 */
 
package com.capgemini.oirs.dto;

/**
 * @author pbahugun
 *
 */
public class Project {
	
	private String project_id;
	private String name;
	private String description;
	private String client_name;
	
	/**
	 * 
	 */
	public Project() {
		super();
	}
	
	/**
	 * Parameterized Constructor
	 */
	public Project(String project_id, String name, String description, String client_name) {
		super();
		this.project_id = project_id;
		this.name = name;
		this.description = description;
		this.client_name = client_name;
	}

	/**
	 * @return the project_id
	 */
	public String getProject_id() {
		return project_id;
	}
	/**
	 * @param project_id the project_id to set
	 */
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the client_name
	 */
	public String getClient_name() {
		return client_name;
	}
	/**
	 * @param client_name the client_name to set
	 */
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}
	
	

}
