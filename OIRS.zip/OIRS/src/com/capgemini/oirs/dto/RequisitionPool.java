/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Pool DAO Interface 
 * 
 */
package com.capgemini.oirs.dto;

public class RequisitionPool {
	
	private String employee_id; 
	private String employee_name; 
	private String skill; 
	private String domain ;
	private int experience;
	private String requisition_id;
	
	public String getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getRequisition_id() {
		return requisition_id;
	}
	public void setRequisition_id(String requisition_id) {
		this.requisition_id = requisition_id;
	}
	public RequisitionPool(String employee_id, String employee_name,
			String skill, String domain, int experience,String requisition_id) {
		super();
		this.employee_id = employee_id;
		this.employee_name = employee_name;
		this.skill = skill;
		this.domain = domain;
		this.experience = experience;
		this.requisition_id=requisition_id;
	}
	public RequisitionPool() {
		super();
	}
	
	

}
