/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition DAO Interface 
 * 
 */
package com.capgemini.oirs.dto;

/**
 * @author pbahugun
 *
 */
public class Requisition {
	
	private String requisition_id;
	private String rm_id;
	private String project_id;
	private String date_created;
	private String date_closed;
	private String current_status;
	private String vaccancy_name;
	private String skill;
	private String domain;
	private int number_required;
	private String rmge_id;
	/**
	 * 
	 */
	public Requisition() {
		super();
	}
	/**
	 * Parameterized Constructor
	 */
	public Requisition(String requisition_id, String rm_id, String project_id, String date_created, String date_closed,
			String current_status, String vaccancy_name, String skill, String domain, int number_required,
			String rmge_id) 
	{
		super();
		this.requisition_id = requisition_id;
		this.rm_id = rm_id;
		this.project_id = project_id;
		this.date_created = date_created;
		this.date_closed = date_closed;
		this.current_status = current_status;
		this.vaccancy_name = vaccancy_name;
		this.skill = skill;
		this.domain = domain;
		this.number_required = number_required;
		this.rmge_id = rmge_id;
	}
	/**
	 * @return the requisition_id
	 */
	public String getRequisition_id() {
		return requisition_id;
	}
	/**
	 * @param requisition_id the requisition_id to set
	 */
	public void setRequisition_id(String requisition_id) {
		this.requisition_id = requisition_id;
	}
	/**
	 * @return the rm_id
	 */
	public String getRm_id() {
		return rm_id;
	}
	/**
	 * @param rm_id the rm_id to set
	 */
	public void setRm_id(String rm_id) {
		this.rm_id = rm_id;
	}
	/**
	 * @return the project_id
	 */
	public String getProject_id() {
		return project_id;
	}
	/**
	 * @param project_id the project_id to set
	 */
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	/**
	 * @return the date_created
	 */
	public String getDate_created() {
		return date_created;
	}
	/**
	 * @param date_created the date_created to set
	 */
	public void setDate_created(String date_created) {
		this.date_created = date_created;
	}
	/**
	 * @return the date_closed
	 */
	public String getDate_closed() {
		return date_closed;
	}
	/**
	 * @param date_closed the date_closed to set
	 */
	public void setDate_closed(String date_closed) {
		this.date_closed = date_closed;
	}
	/**
	 * @return the current_status
	 */
	public String getCurrent_status() {
		return current_status;
	}
	/**
	 * @param current_status the current_status to set
	 */
	public void setCurrent_status(String current_status) {
		this.current_status = current_status;
	}
	/**
	 * @return the vaccancy_name
	 */
	public String getVaccancy_name() {
		return vaccancy_name;
	}
	/**
	 * @param vaccancy_name the vaccancy_name to set
	 */
	public void setVaccancy_name(String vaccancy_name) {
		this.vaccancy_name = vaccancy_name;
	}
	/**
	 * @return the skill
	 */
	public String getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(String skill) {
		this.skill = skill;
	}
	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}
	/**
	 * @param domain the domain to set
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}
	/**
	 * @return the number_required
	 */
	public int getNumber_required() {
		return number_required;
	}
	/**
	 * @param number_required the number_required to set
	 */
	public void setNumber_required(int number_required) {
		this.number_required = number_required;
	}
	/**
	 * @return the rmge_id
	 */
	public String getRmge_id() {
		return rmge_id;
	}
	/**
	 * @param rmge_id the rmge_id to set
	 */
	public void setRmge_id(String rmge_id) {
		this.rmge_id = rmge_id;
	}
	
	

}
