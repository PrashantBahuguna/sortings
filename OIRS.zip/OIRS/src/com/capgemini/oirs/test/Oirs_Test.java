/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : JUnit Test 
 * 
 */
package com.capgemini.oirs.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.oirs.dao.EmployeeDao;
import com.capgemini.oirs.dao.IEmployeeDao;
import com.capgemini.oirs.dao.IRequisitionDAO;
import com.capgemini.oirs.dao.RequisitionDAO;
import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public class Oirs_Test {

	IEmployeeDao employeeDao = new EmployeeDao();
	IRequisitionDAO requisitionDao = new RequisitionDAO();
	
	@Test
	public void testRaiseRequisition()
	{
		Requisition requisition = new Requisition("RQ90", "RM01", "P01", "2018-08-04 00:00:00.0", null, "OPEN", "DEV", "Level2", "SAP", 2, "RMGE01");
		try {
			assertEquals(1, requisitionDao.raiseRequisition(requisition));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void testSetEmployeePassword() {
		try {
			assertEquals(1, employeeDao.setEmployeePassword("RM01", "pass"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testAssignRole() {
		try {
			assertEquals(1, employeeDao.assignRole("E000", "RM"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testAddEmployee() {
		Employee employee = new Employee("E000", "passwordtest", "TEST", "RMG", "TEST", "TEST", 0, "EMP");
		try {
			assertEquals(1, employeeDao.addEmployee(employee));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetEmployeeId() {
		try {
			assertEquals("RMGE01", employeeDao.getEmployeeId("RMGE01"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void testGetEmployeePassword() {
		try {
			assertEquals("password", employeeDao.getEmployeePassword("RMGE01"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}
	/*
	@Test
	public void testGetEmployeeType() {
		try {
			assertEquals("RMGE", employeeDao.getEmployeeType("RMGE01"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetEmployeeName() {
		try {
			assertEquals("Chris Evans", employeeDao.getEmployeeName("RMGE01"));
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetEmployee() {
		Employee employee = new Employee("RM01", "pass", "Robert Maxwell", "P01", "Level3", "JEE", 7, "RM");
		try {
			Employee test =  employeeDao.getEmployee("RM01");
			assertEquals("RM01", test.getEmployee_id());
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}

	

	@Test
	public void testGetHierarchy() {
		String hierarchy[];
		try {
			hierarchy = employeeDao.getHierarchy("E001");
			assertEquals("RM01", hierarchy[0]);
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test
	public void testGenerateEmployeeID() {
		try {
			assertEquals(31, employeeDao.generateEmployeeID());
		} catch (OirsException e) {
			
			e.printStackTrace();
		}
	}

	

	*/

}
