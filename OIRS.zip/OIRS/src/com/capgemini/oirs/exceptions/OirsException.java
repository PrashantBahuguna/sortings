/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : User defined exception class
 * 
 */
package com.capgemini.oirs.exceptions;

public class OirsException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OirsException() {
		// TODO Auto-generated constructor stub
	}

	public OirsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
		//User defined exception raised to the SUPER
	}

}
