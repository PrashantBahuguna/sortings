/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Client UI 
 * 
 */
package com.capgemini.oirs.ui;



import java.nio.Buffer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.oirs.dao.IMessageMapper;
import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.dto.RequisitionPool;
import com.capgemini.oirs.exceptions.OirsException;
import com.capgemini.oirs.service.AdminService;
import com.capgemini.oirs.service.EmployeeService;
import com.capgemini.oirs.service.IAdminService;
import com.capgemini.oirs.service.IEmployeeService;
import com.capgemini.oirs.service.IProjectService;
import com.capgemini.oirs.service.IRequisitionPoolService;
import com.capgemini.oirs.service.IRequisitionService;
import com.capgemini.oirs.service.ProjectService;
import com.capgemini.oirs.service.RequisitionPoolService;
import com.capgemini.oirs.service.RequisitionService;

/**
 * @author pbahugun
 *
 */

/*
 * TODO
 * 2.Display requisitions to RMGE and wherever in order by Status
 * 3.as RM to close a project and update project_id of corresponding emps to RMG
 *  -- remove RMGE project validation for req.
 *  
 */
public class OIRS {
	
	static Logger log=Logger.getRootLogger();

	static String username;
	static String password;
	String buffer;
	ArrayList<Requisition> requisitions;		
	IRequisitionService requisitionService = new RequisitionService();
	

	public static void main(String[] args) 
	{
		OIRS app = new OIRS();
		log.info(IMessageMapper.APP_START);
		IRequisitionService requisitionService = new RequisitionService();
		
		Scanner sc = new Scanner(System.in);		
		Employee employee = null;		
		
		IEmployeeService employeeService = new EmployeeService();
		
		int count=0;

		//flag for do-while iteration
		boolean flag = true; 	
		do 
		{
			
			//check for at max 3 tries			
			if(count==3)
			{
				System.err.println(IMessageMapper.LAST_ATTEMPT);
			}
			if(count>=1)
			{
				System.err.println("No. of tries remaining : "+(3-count));
			}
			System.out.println("\t||===========================================================||");
			System.out.println("\t||                                                           ||");
			System.out.println("\t||***Welcome to Online Internal Recruitment Systemt (OIRS)***||");
			System.out.println("\t||                                                           ||");
			System.out.println("\t||===========================================================||");
			System.out.println("\nPlease Login with your credetials");
			System.out.println("Username : ");
			username = sc.nextLine();
			System.out.println("Password : ");
			password = sc.nextLine();
			count++;
			log.info("<<<<----LOGIN PAGE LAUNCHED---->>>>");
			
			//Validate entered username from DB
			try {
				employee = employeeService.getEmployee(username);
				log.info("[Employee Exists...Session Bean Initialized]");
			} catch (OirsException e1) {
				System.err.println("Something went wrong while validating username !! : <<"+e1.getMessage()+" >>");
				log.error("[!Employee Does not exist!]");
				
			}		
			
			//Validate entered password against username from the DB
			try {
				flag = employeeService.validatePassword(employee.getPassword(), password);
			} catch (OirsException e1) {
				System.err.println("Something went wrong while checking password !! : <<"+e1.getMessage()+" >>");
				flag = false;
				log.error("[!Error while validating user and password!]");
			}
			if(!flag)
			{
				System.out.println("Username and Password does not match !!!");
				log.info("[Username and Password does not match]");
				continue;
			}
			
			System.out.println(IMessageMapper.LOGIN_SUCCESSFUL);
			log.info("<<<<----Login Successfull---->>>>");
			System.out.println("=============================================================");			
			System.out.println("\n\nWelcome "+employee.getName()+" !!");			
			log.info("USER : "+employee.getName()+" logged in OIRS !!");
			log.info(employee.getEmployee_id()+" session started !!");			
			System.out.println("\nAccess Rights : "+employee.getEmp_type());			
			String choice="0";
			
			//Dynamic Landing page for each user as per their access rights
			switch(employee.getEmp_type())
			{
			/*
			 * 
			 * ************ Resource Manager ***************
			 * 
			 */
			case "RM":
				
				requisitionService = new RequisitionService();
				do 
				{	
					//impl hierarchy for RM i.e new () for retrieving RMGE and use this in accept requisition (suggested by RMGE)
					log.info("Inside RM Session");
					System.out.println("\n\n");
					System.out.println("\t||=========================MAIN MENU=========================||");
					System.out.println("\t||                                                           ||");
					System.out.println("\t||                1. View Profile                            ||");
					System.out.println("\t||                2. Change Password                         ||");
					System.out.println("\t||                3. Raise Requisition                       ||");
					System.out.println("\t||                4. View Requisition                        ||");
					System.out.println("\t||                5. Accept/Reject Allocations               ||");
					System.out.println("\t||                6. Generate Reports                        ||");
					System.out.println("\t||                7. Close a Project                         ||");
					System.out.println("\t||                8. Exit                                    ||");
					System.out.println("\t||                                                           ||");
					System.out.println("\t||===========================================================||");
					System.out.println("\nPlease enter your choice : ");
					choice = sc.nextLine();
					String projectId;
					String status;
					String vaccancy_name;
					String skill;
					String domain;
					String number_required = "2";
					String rmge_id="TBD";
					String ch;
					switch (choice) 
					{
						case "1"://View Profile
							app.displayEmployee(employee);
							log.info("Profile displayed");
							break;
						
						case "2"://Change Password
							try 
							{
								employeeService.updatePassword(employee);
								System.out.println("<<< Password updated successfully !! >>>");
								log.info("[Password Updated Successfull]");
								
							} catch (OirsException e) 
							{
								System.err.println("Something went wrong while updating password. <<<<"+e.getMessage()+">>>>");
								log.error("[Error while changing password!!]");
							}
							
							break;
							
						case "3"://Raise Requisition
							
							LocalDateTime date_now = LocalDateTime.now();
							
							System.out.println("----Requisition Details----");		
							String requisition_id="RQ10";
							try {
								requisition_id = requisitionService.generateRequisitionID();
							} catch (OirsException e1) {
								System.err.println("Something went wrong while generating Requisition ID !!!");
							}
							
							System.out.println("Requisition ID : "+requisition_id);
							System.out.println("Requisition Manager ID : "+employee.getEmployee_id());
							System.out.println("Enter Project ID : ");
							projectId = sc.nextLine();	
							IProjectService projectService = new ProjectService();
							if(!projectService.validateProject(projectId))
							{
								System.err.println("Project ID Does not exist !!");
								break;
							}
							status = "OPEN";	//Status by default OPEN
							System.out.println("Enter Vaccaancy name : ");
							vaccancy_name = sc.nextLine();
							
							System.out.println("Select Skill Required : ");
							System.out.println("1) Level1");
							System.out.println("2) Level2");
							System.out.println("3) Level3");
							System.out.println("4) Level4");
							ch = sc.nextLine();
							while(true)
							{
								if("1".equals(ch)||"Level1".equalsIgnoreCase(ch))
								{
									skill="Level1";
									break;
								}									
								else if ("2".equals(ch)||"Level2".equalsIgnoreCase(ch)) {
									skill="Level2";
									break;
								}
								else if("3".equals(ch)||"Level3".equalsIgnoreCase(ch)){
									skill="Level3";
									break;
								}
								else if("4".equals(ch)||"Level4".equalsIgnoreCase(ch)){
									skill="Level4";
									break;
								}
								else {
									System.out.println("Invalid Input !! Try Again ");
									ch = sc.nextLine();
								}
							}
							int number=2;
							System.out.println("Enter Domain required : ");
							domain = sc.nextLine();
							System.out.println("Enter Number required : ");
							try {
								number_required = sc.nextLine();
								if(employeeService.isValidExperience(number_required))
								{
									number = Integer.parseInt(number_required);
								}
							} catch (Exception e) {
								System.err.println("Please enetr a valid int value");
							}
							Requisition requisition = new Requisition(requisition_id, employee.getEmployee_id(), projectId, date_now.toString(), null, status, vaccancy_name, skill, domain, number, rmge_id);
							
							try 
							{								
								if(requisitionService.raiseRequisition(requisition)>0)
								{
									System.out.println("<<< Requisition raised successfully !! >>>");
									//requisitionService.raiseRequisition(requisition);
									//employeeService.raiseRequisition()
									log.info("Requisition raised successfully");
								}
								else {
									System.err.println("Requisition NOT raised !! Try again");
								}
								
							} 
							catch (OirsException e) {
								System.err.println("Something went wrong while raising requisiton !! <<"+e.getMessage()+">>");
								log.error("[Error while raising requisiton]");
							}						
							
							break;
							
						case "4"://View Requisition
								String requisitionId;
								System.out.println("Please enter the Requisition ID : ");
								requisitionId = sc.nextLine();
								try 
								{
									app.displayRequisition(requisitionId);
									log.info("Requisition displayed successfully");
								} 
								catch (OirsException e) {
									System.err.println("Something went wrong while displaying requisiton !! <<"+e.getMessage()+">>");
									log.error("[Error while displaying requisiton]");
								}							
								break;
						
						case "5"://Accept/Reject Allocations
								String response;								
								IRequisitionPoolService requisitionPoolService = new RequisitionPoolService();
								try {
									System.out.println("Please enter the Requisition ID : ");
									requisitionId = sc.nextLine();
									System.out.println("Suggested potential resources for your");
									app.viewRequisitionPoolById(requisitionId);
									System.out.println("Enter Y to accept and N to reject the proposed allocation : ");
									response=sc.nextLine();
									if("Y".equalsIgnoreCase(response))
									{
										int updateProject = employeeService.updateProjectId(requisitionId);
										int acceptReq = requisitionService.acceptRequisition(requisitionId,employee.getEmployee_id());
										//update the project id of employee
										//close the requisition
										//set the date_closed
										//clear the requisition_pool table where requisition id
										if(updateProject >0 && acceptReq>=2)
										{
											System.out.println("Successfully Accepted the resources sugesstion for requisition ID : "+requisitionId+" !!!");
											log.info("[Successfully Accepted the resources sugesstion]");
										}
										else
										{
											System.out.println("Allocations NOT accepted !! Something went wrong, please try again");
										}
										
										
									}
									else if("N".equalsIgnoreCase(response))
									{
										requisitionPoolService.clearRequisitionPool(requisitionId);
										System.out.println("Resources suggestion for the Requisiton : "+requisitionId+" is Successfully rejected");
										log.info("[Successfully Rejected the resources sugesstion]");
									}
									else {
										System.err.println("Invalid Input !!! Try Again !!");
										log.error("[Invalid entry at Accpet/Reject Requisiton]");
										//continue;
									}
									
								} catch (OirsException e) {
									System.err.println("Something went wrong while Accepting/Rejecting the allocated resources  !! <<"+e.getMessage()+">>");
									log.error("[Something went wrong while Accepting/Rejecting the allocated resources  !!]");
								}
								break;
							
						case "6"://Generate Reports
								String rep="0";						
								System.out.println("\n\n");
								System.out.println("\t*****************GENERATE REPORTS********************");
								System.out.println("\t*         1. View Open Requisitions                 *");
								System.out.println("\t*         2. View Closed Requisitions               *");
								System.out.println("\t*         3. View Requisition By Domain             *");
								System.out.println("\t*         4. View Requisition By Skill              *");
								System.out.println("\t*         5. View Requisition By Project ID         *");
								System.out.println("\t*****************************************************");
								System.out.println("\nPlease Enter your choice : ");
								rep = sc.nextLine();								
								switch (rep) 
								{
								case "1"://Open Requisitions
									try {
										app.viewRequisitionsByStatus(employee.getEmployee_id(),"OPEN");
										log.info("[Successfully displayed open requisitons]");
									} catch (OirsException e) {
										System.err.println("Something went wrong while viewing OPEN Requistions !!! <<"+e.getMessage()+">>");
										log.error("[Something went wrong while viewing OPEN Requistions !!!]");
									}
									
									break;
								
								case "2"://Closed Requisitions
									try {
										app.viewRequisitionsByStatus(employee.getEmployee_id(),"CLOSED");
										log.info("[Successfully displayed closed requisitons]");
									} catch (OirsException e) {
										System.err.println("Something went wrong while viewing CLOSED Requistions !!! <<"+e.getMessage()+">>");
										log.error("Something went wrong while viewing CLOSED Requistions !!!");
									}
									break;
								
								case "3"://Requisition by Domain
									System.out.println("Please enter the Domain you want to view by : ");
									domain = sc.next();
									try {
										app.viewRequisitionsByDomain(employee.getEmployee_id(),domain);
										log.info("[Successfully displayed domain requisitons]");
									} catch (OirsException e) {
										System.err.println("Something went wrong while viewing Requistions by Domain !!! <<"+e.getMessage()+">>");
										log.error("Something went wrong while viewing Requistions by Domain !!!");
									}
									break;
								
								case "4"://Requisition by Skill
									System.out.println("Please enter the Skill you want to view by : ");
									skill = sc.next();
									try {
										app.viewRequisitionsBySkill(employee.getEmployee_id(),skill);
										log.info("[Successfully displayed skill requisitons]");
									} catch (OirsException e) {
										System.err.println("Something went wrong while viewing Requistions by Skill !!! <<"+e.getMessage()+">>");
										log.error("Something went wrong while viewing Requistions by Skill !!!");
									}
									break;
								
								case "5"://Requisition by Project ID
									System.out.println("Please enter the Project ID you want to view by : ");
									projectId = sc.next();
									projectService = new ProjectService();
									if(!projectService.validateProject(projectId))
									{
										System.err.println("Project ID Does not exist !!");
										break;
									}
									try 
									{
										app.viewRequisitionsByProjectId(employee.getEmployee_id(),projectId);
										log.info("[Successfully displayed Project ID requisitons]");
										
									} catch (OirsException e) {
										System.err.println("Something went wrong while viewing Requistions by Project ID !!! <<"+e.getMessage()+">>");
										log.error("Something went wrong while viewing Requistions by Project ID !!!");
									}
									break;											
								
								default:
									System.out.println("Invalid Input");
									log.info("[Invalid input at RM-Generate Reports]");
									break;
								
								}							
								break;
								
						case "7"://Close a project
								String pid;
								System.out.println("Please enter the Project-ID of the project you want to close : ");
								pid=sc.nextLine();
								projectService = new ProjectService();
								
								if(!projectService.validateProject(pid))
								{
									System.err.println("Project Does not exist !!");
									break;
								}
								try 
								{	if(projectService.closeProject(pid)>0)
									{	
										System.out.println("Project successfully closed and resources released !! ");
										log.info("Project successfully closed and resources released");
									}
									else
									{
										System.err.println("Project does not exist !!! Cannot close it");
										log.error("Project does not exist !!! Cannot close it");
									}
										
								} 
								catch (OirsException e) 
								{
									System.err.println("Something went wrong !! <<"+e.getMessage()+">>");
									log.error("Error while closing a project :"+pid);
								}
								break;
						
						case "8"://EXIT
								System.out.println("\nThank You for using OIRS.");
								System.out.println("Have a nice day "+employee.getName()+"!!");
								log.info("<<USER : "+employee.getName()+" EXIT>>");
								log.info("--<<Session ID : "+employee.getEmployee_id()+" is now terminated !!>>--");
								break;
							
						default:
								System.err.println("Invalid Input!!");
								System.err.println("Please try again !!");
								log.info("Invalid input by RM at main menu");
								continue;
								
					}//RM switch ends 
					
				} while ("8".equals(choice)==false);//RM do-while ends		
				
				log.info("<<RM Session ends>>");
				break;
				//RM Session ends here
				
				/*
				 * 
				 * ************ Resource Manager Group Executive ***************
				 * 
				 */
			case "RMGE":
				
				requisitionService = new RequisitionService();
				do {
					log.info("<<RMGE Session Started>>");
					System.out.println("\n\n");
					System.out.println("\t||=========================MAIN MENU=========================||");
					System.out.println("\t||                                                           ||");
					System.out.println("\t||          1. View Profile                                  ||");
					System.out.println("\t||          2. Change Password                               ||");
					System.out.println("\t||          3. View Undertaken Requisitions                  ||");
					System.out.println("\t||          4. Undertake Requisition (ALL or RM Specific)    ||");
					System.out.println("\t||          5. Allocate Resources into Requisition           ||");
					System.out.println("\t||          6. Generate Reports                              ||");
					System.out.println("\t||          7. Exit                                          ||");
					System.out.println("\t||                                                           ||");
					System.out.println("\t||===========================================================||");
					System.out.println("\nPlease enter your choice : ");							
					choice = sc.nextLine();
					
					switch (choice) 
					{
					case "1"://View Profile
							app.displayEmployee(employee);	
							log.info("Profile displayed");
							break;
						
					case "2"://Change Password
							try 
							{
								employeeService.updatePassword(employee);
								System.out.println("<<< Password updated successfully !! >>>");
								log.info("Password updated");
								
							} catch (OirsException e) 
							{
								System.err.println("Something went wrong while updating password. <<"+e.getMessage()+">>");
								log.error("[Error while changing password]");
							}							
							break;
							
					case "3"://View Undertaken Requisitions						
							try {
								app.viewUndertakenRequisitions(employee.getEmployee_id());
								log.info("Undertaken requisitions displayed");
							} catch (OirsException e1) {
								System.err.println("Something went wrong while displaying your undertaken requisitions");
								log.error("Error while displaying your undertaken requisitions");
							}
							
							break;
					
					case "4"://Undertake Requisition (ALL or RM Specific)
							String choice1;
							String rmId;
							System.out.println("**View Requisition**");
							System.out.println("1. RM Specific Requisition");
							System.out.println("2. All Requisitions");
							System.out.println("Please enter your choice : ");
							choice1 = sc.nextLine();
						
							switch (choice1) 
							{
								case "1":// RM Specific Requisition
										System.out.println("Please enter the RM ID : ");
										rmId = sc.nextLine();
										try 
										{
											app.displayRequisitionByRM(rmId);
											log.info("RM Specific requisiton displayed");
										} catch (OirsException e) 
										{
											System.err.println("Something went wrong while displaying requisition by RM ID ");
											log.error("[Error while displaying requisition by RM ID]");
										}
										break;
									
								case "2"://All Requisitions
										try 
										{
											app.displayAllRequisitions();
											log.info("All requisitons displayed");
										} catch (OirsException e) 
										{
											System.err.println("Something went wrong while displaying all requisitions ");
											log.error("[Error while displaying all requisitions]");
										}
										break;
									
								default:
										System.out.println("Invalid Input");
										log.info("Invalid input by RMGE at internal menu");
										continue;
										
							}
							String reqId;
							System.out.println("\nEnter the Requisition ID you want to undertake : ");
							reqId = sc.nextLine();
							try 
							{
								if(requisitionService.undertakeRequisition(reqId,employee.getEmployee_id())>0)
								{
									System.out.println("<<< Requisition undertaking successful !! >>>");
									log.info("Requisition undertaking successful !!");
								}
								else 
								{
									System.out.println("<<< Requisition undertaking NOT successful !! >>>");
									log.info("Requisition undertaking NOT successful !!");
								}
								
								
							} catch (OirsException e) 
							{
								System.err.println("Something went wrong while undertaking your requisition !!");
								log.error("[Error while undertaking your requisition !!]");
							}
							break;
						
					case "5"://Allocate Resources into Requisition
							IRequisitionPoolService requisitionPoolService = new RequisitionPoolService();
							ArrayList<String> emp_ids = new ArrayList<String>();
							int allocation;
						
							
							try {
								System.out.println("\nEnter the Requisition ID of the requisition : ");
								reqId=sc.nextLine();
								
								
								//Get the required number of requisitions for a requisition
								allocation=requisitionService.getResourcesRequired(reqId);
								if(allocation>0)
								{
									if(app.viewResourcePool(allocation))
									{
										System.out.println("\n\nNumber of Resources required : " + allocation);
										System.out.println("\nPlease enter the Employee ID(s) of the potential resources : ");
										
										for(int i=0;i<allocation;i++)
										{
											//s = sc.next();
											emp_ids.add(sc.nextLine());
										}
										
										for(String s : emp_ids)
											System.err.println(s);
										if(requisitionPoolService.initRequisitionPool(emp_ids,reqId)>=2)
										{
											System.out.println("\n[Resouce Pool successfully initialized !]");
											app.viewRequisitionPool();
											log.info("Allocated Resources into Requisition");
										}
										else {
											System.out.println("\nResources are not added !! Please Try again !!");
										}
									}
									
								}
								else {
									System.err.println("\nRequisition does not exist !!!");
									log.error("Requisition does not exist");
								}
								
								
								
								
							} catch (OirsException e) {
								System.err.println("Something went wrong while initializing resource pool <<"+e.getMessage()+">>");
								log.error("Error while initializing resource pool");
							}
							
							break;
						
					case "6"://Generate Reports
							String rep = "0";
							System.out.println("\n\n");
							System.out.println("\t*****************GENERATE REPORTS****************");
							System.out.println("\t*		1. View Open Requisitions                 *");
							System.out.println("\t*		2. View Closed Requisitions               *");
							System.out.println("\t*		3. View Requisition By Domain             *");
							System.out.println("\t*		4. View Requisition By Skill              *");
							System.out.println("\t*		5. View Requisition By Project ID         *");
							System.out.println("\t*************************************************");
							System.out.println("\nPlease Enter your choice : ");						
							rep = sc.nextLine();
							
							switch (rep) 
							{
							case "1"://Open Requisitions
								try {
									app.viewRequisitionsByStatus(employee.getEmployee_id(),"OPEN");
									log.info("Displayed Open Requisitions");
								} catch (OirsException e) {
									System.err.println("Something went wrong while viewing OPEN Requistions !!! <<"+e.getMessage()+">>");
									log.error("[Error while viewing OPEN Requistions !!!]");
								}
								
								break;
							
							case "2"://Closed Requisitions
								try {
									app.viewRequisitionsByStatus(employee.getEmployee_id(),"CLOSED");
									log.info("Displayed Closed Requisitions");
								} catch (OirsException e) {
									System.err.println("Something went wrong while viewing CLOSED Requistions !!! <<"+e.getMessage()+">>");
									log.error("[Error while viewing CLOSED Requistions !!!]");
								}
								break;
							
							case "3"://Requisition by Domain
								System.out.println("Please enter the Domain you want to view by : ");
								String domain = sc.nextLine();
								try {
									app.viewRequisitionsByDomain(employee.getEmployee_id(),domain);
									log.info("Display Requisition by Domain");
								} catch (OirsException e) {
									System.err.println("Something went wrong while viewing Requistions by Domain !!! <<"+e.getMessage()+">>");
									log.error("[Something went wrong while viewing Requistions by Domain !!!]");
								}
								break;
							
							case "4"://Requisition by Skill
								System.out.println("Please enter the Skill you want to view by : ");
								String skill = sc.nextLine();
								try {
									app.viewRequisitionsBySkill(employee.getEmployee_id(),skill);
									log.info("Display Requisition by Skill");
								} catch (OirsException e) {
									System.err.println("Something went wrong while viewing Requistions by Skill !!! <<"+e.getMessage()+">>");
									log.error("[Something went wrong while viewing Requistions by Skill !!!]");
								}
								break;
							
							case "5"://Requisition by Project ID
								System.out.println("Please enter the Project ID you want to view by : ");
								String projectId = sc.nextLine();
								IProjectService projectService = new ProjectService();
								if(!projectService.validateProject(projectId))
								{
									System.err.println("Project ID Does not exist !!");
									break;
								}
								try 
								{
									app.viewRequisitionsByProjectId(employee.getEmployee_id(),projectId);
									log.info("Display Requisition by Project ID");
									
								} catch (OirsException e) {
									System.err.println("Something went wrong while viewing Requistions by Project ID !!! <<"+e.getMessage()+">>");
									log.error("[Something went wrong while viewing Requistions by Project ID !!!]");
								}
								break;											
							
							default:
								System.err.println("Invalid Input!!");
								System.err.println("Please try again !!");
								log.info("Invalid Input at RMGE");
								continue;
							}
							break;
							
						
					case "7"://EXIT
							System.out.println("\nThank You for using OIRS.");
							System.out.println("Have a nice day "+employee.getName()+"!!");
							log.info("RMGE Session close initialized");
							break;

					default://Invalid Input
							System.err.println("Invalid Input!!");
							System.err.println("Please try again !!");
							log.info("Invalid Input at RMGE menu");
							continue;
					}// RMGE switch ends
	
				} while ("7".equals(choice)==false);//RMGE do-while ends
				
				log.info("RMGE Session ends...");
				break;
				//RMGE Session ends
				
				
				/*
				 * 
				 * ************ Employee ***************
				 * 
				 */
			case "EMP":
				
				do {
					log.info("EMP Session begins");
					System.out.println("\n\n");
					System.out.println("\t*********************MENU*********************************");
					System.out.println("\t*		1. View Profile                          *");
					System.out.println("\t*		2. Change Password                       *");
					System.out.println("\t*		3. View Project Reporting Hierarchy      *");
					System.out.println("\t*		4. Exit                                  *");
					System.out.println("\t**********************************************************");
					System.out.println("\nPlease Enter your choice : ");
					choice = sc.next();
					switch (choice) 
					{
						case "1"://View Profile
								app.displayEmployee(employee);
								log.info("Profile Displayed");
								break;
						
						case "2"://Change Password
								try 
								{
									employeeService.updatePassword(employee);
									System.out.println("\t<<< Password Updated Successfully !!! >>>");
									log.info("Password updated successfully");
								} 
								catch (OirsException e) 
								{
									System.err.println("Something went wrong while updating password. <<"+e.getMessage()+">>");
									log.error("");
								}
								
								break;
							
						case "3"://View Project Reporting Hierarchy
								String[] hierarchy;
								try 
								{
									hierarchy = employeeService.getHierarchy(employee.getEmployee_id());
									
									if(hierarchy[0]==null || hierarchy[0]=="")
									{
										System.out.println("You do not have a project allocated. Hence there is no reporting hierarchy.");
										break;
									}
									System.out.println("\nYour Project Hierarchy is ");
									System.out.println("\nMANAGER ID   : "+hierarchy[0]);
									System.out.println("\nMANAGER Name : "+hierarchy[1]);
									log.info("Hierarchy Displayed");
									
								} catch (OirsException e) 
								{
									System.err.println("Something went wrong while retreiving hierarchy. <<"+e.getMessage()+">>");							
									log.error("Error while displaying hierarchy");
								}
								
								break;
							
						case "4"://EXIT Case
								System.out.println("\nThank You for using OIRS.");
								System.out.println("Have a nice day "+employee.getName()+"!!");
								log.info("Ending EMP Session....");
								break;
	
						default://Invalid input case
								System.err.println("Invalid Input!!");
								System.err.println("Please try again !!");
								log.info("Invalid input at EMP Menu");
								continue;
									
						}//Employee switch ends
						
					
										
				} while ("4".equals(choice)==false); //EMP do-while ends
				
				log.info("ENP Session ended");				
				break;
				//EMPLOYEE Session ends
				
				
				/*
				 * 
				 * ************ Admin ***************
				 * 
				 */
			case "ADMIN":
				//ADMIN rights functionalities
				IAdminService adminService = new AdminService();
				
				do {
					log.info("Admin Session begins");
					System.out.println("\n\n");
					System.out.println("\t||==================MAIN MENU========================||");
					System.out.println("\t||                                                   ||");
					System.out.println("\t||          1. Add Employee                          ||");
					System.out.println("\t||          2. Delete Employee                       ||");
					System.out.println("\t||          3. Assign Roles                          ||");
					System.out.println("\t||          4. View Employees                        ||");
					System.out.println("\t||          5. Exit                                  ||");
					System.out.println("\t||                                                   ||");
					System.out.println("\t||===================================================||");
					System.out.println("\nPlease enter your choice : ");
					
					choice = sc.nextLine();
					
					switch (choice) 
					{
					case "1"://Add employee
							String npassword;
							String nName="";							
							String nSkill;
							String nDomain;
							String nExperience;
							String nEmp_type;
							String ch;
							System.out.println("Please enter the following details of new employee :");
							System.out.println("Enter Password of the new User : ");
							npassword = sc.nextLine();
							//validate the password
							while(!adminService.validatePassword(npassword))
							{			
								System.err.println("Invalid Password !! Length should be greater between [8-16] and should contain characters !! Try again");
								npassword = sc.nextLine();								
							}
							
							System.out.println("Enter Name : ");
						
							nName = sc.nextLine();
							while(adminService.isValidName(nName)==false)
							{
								System.err.println("Invalid Name !! Try again !!");
								nName = sc.nextLine();
							}
							
							System.out.println("Select Skill : ");
							System.out.println("1) Level1");
							System.out.println("2) Level2");
							System.out.println("3) Level3");
							System.out.println("4) Level4");
							ch = sc.nextLine();
							while(true)
							{
								if("1".equals(ch)||"Level1".equalsIgnoreCase(ch))
								{
									nSkill="Level1";
									break;
								}									
								else if ("2".equals(ch)||"Level2".equalsIgnoreCase(ch)) {
									nSkill="Level2";
									break;
								}
								else if("3".equals(ch)||"Level3".equalsIgnoreCase(ch)){
									nSkill="Level3";
									break;
								}
								else if("4".equals(ch)||"Level4".equalsIgnoreCase(ch)){
									nSkill="Level4";
									break;
								}
								else {
									System.out.println("Invalid Input !! Try Again ");
									ch = sc.nextLine();
								}
							}
							/*while(adminService.isValidSkill(nSkill)==false)
							{
								System.err.println("Invalid Skill !! It should be of type \"Level#\" Try again !!");
								nSkill = sc.nextLine();
							}*/
							System.out.println("Domain : ");
							nDomain = sc.nextLine();
							System.out.println("Experience : ");
							nExperience = sc.nextLine();
							int number=2;
							if(adminService.isValidExperience(nExperience))
							{
								number = Integer.parseInt(nExperience);
							}
							
							System.out.println("Employee Type\n  1.EMP\n  2.RM\n  3.RMGE");
							sc.nextLine();
							ch = sc.nextLine();
							
							while(true)
							{
								if("1".equals(ch)||"EMP".equalsIgnoreCase(ch))
								{
									nEmp_type="EMP";
									break;
								}									
								else if ("2".equals(ch)||"RM".equalsIgnoreCase(ch)) {
									nEmp_type="RM";
									break;
								}
								else if("3".equals(ch)||"RMGE".equalsIgnoreCase(ch)){
									nEmp_type="RMGE";
									break;
								}
								else {
									System.out.println("Invalid Input !! Try Again ");
									ch = sc.nextLine();
								}
							}
							
							Employee nEmployee = new Employee("", npassword, nName, "RMG", nSkill, nDomain, number, nEmp_type);
							try 
							{
								if(adminService.addEmployee(nEmployee)>0)
								{	
									System.out.println("User successfully added !!");
									app.displayEmployee(nEmployee);
									log.info("User added successfully");
								}
								else 
								{
									System.out.println("User NOT added successfully !!");
									log.info("Something went wrong while adding employee");
								}
								
								
							} catch (OirsException e) {
								System.err.println("Something went wrong while adding employee !!!<<"+e.getMessage()+">>");
								log.error("Exception in adding user to DB");
							}
							break;
					
					case "2"://Delete Employee
							System.out.println("Please Enter the Employee ID of the User you want to delete : ");
							String emp_id = sc.nextLine();
							try 
							{
								if(adminService.deleteEmployee(emp_id)>0)
								{
									System.out.println(emp_id+" Successfully Deleted !!!");
									log.info("User deleted succesfully");
								}
								else
								{
									System.err.println("Deletion Unsuccessful !!! User does not exist");
									log.error("Error while deleting user");
								}
								
								
							} catch (OirsException e) {
								System.err.println("Something went wrong while deleting employee !!!<<"+e.getMessage()+">>");
								log.error("Exception while deleting user");
							}
							
							break;
						
					case "3"://Assign Roles
							System.out.println("Please Enter the EMPID of the User you want to assign new role : ");
							
							emp_id = sc.nextLine();
							if(adminService.isValidUser(emp_id))
							{
								System.out.println("Please Enter the New Role : ");
								System.out.println("\n  1.EMP\n  2.RM\n  3.RMGE");
								
								ch = sc.nextLine();
								nEmp_type=null;
								while(true)
								{
									if("1".equals(ch)||"EMP".equalsIgnoreCase(ch))
									{
										nEmp_type="EMP";
										break;
									}									
									else if ("2".equals(ch)||"RM".equalsIgnoreCase(ch)) {
										nEmp_type="RM";
										break;
									}
									else if("3".equals(ch)||"RMGE".equalsIgnoreCase(ch)){
										nEmp_type="RMGE";
										break;
									}
									else {
										System.out.println("Invalid Input !! Try Again ");
										ch = sc.nextLine();
									}
								}
								try 
								{
									if(adminService.assignRole(emp_id,nEmp_type)>0)
									{	System.out.println("<<< New role assigned successfully !! >>>");
										log.info("User role updated successfully");
									}
									else {
										System.out.println("Operation unsuccessful !!");
										log.error("Error in assigning new roles");
									}
									
								} catch (OirsException e1) {
									System.err.println("Something went wrong while assigning new role to employee !!! <<"+e1.getMessage()+">>");
									log.error("Exception in assinging new role to user");
								}
							}
							else {
								System.err.println("Cannot assign new role !!");
							}
							
							
							break;
						
					case "4"://View employee
							try 
							{
								app.viewAllEmployees();
								log.info("User displayed successfully");
								
							} catch (OirsException e) {
								System.err.println("Something went wrong while displaying all employees !!! <<"+e.getMessage()+">>");
								log.error("Error while displaying user");
							}
							break;
							
						
					case "5"://EXIT Case
							System.out.println("\nThank You for using OIRS.");
							System.out.println("Have a nice day "+employee.getName()+"!!");
							log.info("Ending Admin session...");
							break;	
					
						
					default:
							System.err.println("Invalid Input!!");
							System.err.println("Please try again !!");
							log.info("Invlaid input in admin menu");
							continue;
					
					}// admin switch ends					
										
				}while("5".equals(choice)==false); //admin do-while ends
				
				log.info("Admin Session Ends");
				break;
				
				//Admin session ends
				
			
			default://Invalid input case (Outer default case of invalid emp-type)
					System.err.println("Something went wrong !!");
					log.info("Invalid EMP-TYPE <<ERROR>>");
					continue;
			}

		} while (flag==false&&count<=3);//Login do-while implementation ends
		log.info("<<<<<<<<<<<APPLICAION TERMINATED>>>>>>>>>>>");
		
		sc.close();
	}
	
	/*
	 * 
	 * --------------UI Methods------------
	 * 
	 */
	
	public void displayEmployee(Employee employee) 
	{
		//Display the details of an employee (Bean object)
		System.out.println("\n--------------USER PROFILE--------------");
		System.out.println("\n    ID          : "+employee.getEmployee_id());
		System.out.println("\n    Name        : "+employee.getName());
		System.out.println("\n    Project-ID  : "+employee.getProject_id());
		System.out.println("\n    Skill       : "+employee.getSkill());
		System.out.println("\n    Domain      : "+employee.getDomain());
		System.out.println("\n    Experience  : "+employee.getExperience());
		System.out.println("\n    EMP Type    : "+employee.getEmp_type());
		
	}
	
	public boolean viewResourcePool(int allocation) throws OirsException
	{
		// Display resource pool
		IEmployeeService employeeService = new EmployeeService();
		ArrayList<Employee> employees = new ArrayList<Employee>();		
		employees=employeeService.viewResourcePool();
		if(employees.size()>=allocation)
		{
			System.out.println("\nEMPLOYEE_ID\t    EMPLOYEE_NAME\t\tSKILL\t  DOMAIN\t\tEXPERIENCE");
			for(Employee e:employees)
			{
				System.out.format("\n  %-6s\t    %-20s\t%-6s\t  %-20s\t%d", e.getEmployee_id(),e.getName(),e.getSkill(),e.getDomain(),e.getExperience());
				
			}
			return true;
		}
		else {
			System.out.println("The resource pool has insufficient resoures to fullfill the requisition request !!!");
			return false;
		}
		
		
	}
	
	//-------------Employee UI ends----------
	
	//-------------Admin UI Starts-----------
	
	public void viewAllEmployees() throws OirsException 
	{
		// Display all employees
		IAdminService adminService = new AdminService();
		ArrayList<Employee> employees = new ArrayList<Employee>();
		try {
			employees=adminService.viewAllEmployees();
		} catch (OirsException e1) {
			throw new OirsException();
		}
		System.out.println("\nEMPLOYEE_ID\tPASSWORD\t\t    NAME\t\t\tPROJECT ID\t\tSKILL\t\tDOMAIN\t\t    EXPERIENCE\t    EMPLOYEE TYPE");
		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		for(Employee e:employees)
		{
			//System.out.println("  %6s"+e.getEmployee_id()+"\t\t"+e.getPassword()+"\t\t"+e.getName()+"\t"+e.getProject_id()+"\t"+e.getSkill()+"\t"+e.getDomain()+"\t"+e.getExperience()+"\t"+e.getEmp_type());
			System.out.format("\n  %-8s\t%-16s\t%-25s\t  %-10s\t\t%-6s\t\t%-20s\t%-2d\t\t%-6s",e.getEmployee_id(),e.getPassword(),e.getName(),e.getProject_id(),e.getSkill(),e.getDomain(),e.getExperience(),e.getEmp_type());
		}
		
	}
	
	//----------- Admin UI Ends-------------
	
	//------------Requisition Pool UI STarts--------------
	
	public void viewRequisitionPool() throws OirsException 
	{
		// Display requisition pool
		IRequisitionPoolService requisitionPoolService = new RequisitionPoolService();
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		requisitionPools=requisitionPoolService.viewRequisitionPool();
		if(requisitionPools.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else 
		{
			System.out.println("\nEMPLOYEE_ID\t    EMPLOYEE_NAME\t\tSKILL\t  DOMAIN\t\tEXPERIENCE");
			for(RequisitionPool r:requisitionPools)
			{
				System.out.format("\n  %-6s\t    %-20s\t%-6s\t  %-20s\t%d", r.getEmployee_id(),r.getEmployee_name(),r.getSkill(),r.getDomain(),r.getExperience());
				
			}
		}		
	}
	
	public void viewRequisitionPoolById(String req_id) throws OirsException 
	{
		// Display requisition pool by requisition id
		IRequisitionPoolService requisitionPoolService = new RequisitionPoolService();
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		requisitionPools=requisitionPoolService.viewRequisitionPoolById(req_id);
		if(requisitionPools.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else 
		{
			System.out.println("\nEMPLOYEE_ID\tEMPLOYEE_NAME\t\tSKILL\tDOMAIN\tEXPERIENCE");
			for(RequisitionPool r:requisitionPools)
			{
				System.out.println(r.getEmployee_id()+"\t"+r.getEmployee_name()+"\t"+r.getSkill()+"\t"+r.getDomain()+"\t"+r.getExperience());
			}
		}		
	}
	
	//------------Requisition Pool UI STarts--------------
	
	//------------Requisition UI STarts--------------
	
	public void displayRequisition(String requisitionId)	throws OirsException 
	{
		//Display requisition by requisition id
		Requisition requisition = new Requisition();
		IRequisitionService requisitionService = new RequisitionService();
		requisition = requisitionService.displayRequisition(requisitionId);		
		System.out.println("\n--------------Requisition Details-----------------");
		System.out.println(" Requisition ID  : "+requisition.getRequisition_id());
		System.out.println(" RM ID           : "+requisition.getRm_id());
		System.out.println(" Project ID      : "+requisition.getProject_id());
		System.out.println(" Date Created    : "+requisition.getDate_created());
		System.out.println(" Date Closed     : "+requisition.getDate_closed());
		System.out.println(" Current Status  : "+requisition.getCurrent_status());
		System.out.println(" Vaccany Name    : "+requisition.getVaccancy_name());
		System.out.println(" Skill           : "+requisition.getSkill());
		System.out.println(" Domain          : "+requisition.getDomain());
		System.out.println(" Number Required : "+requisition.getNumber_required());
		System.out.println(" RMGE ID         : "+requisition.getRmge_id());
	
	}
	
	public void displayRequisitionByRM(String rmId) throws OirsException 
	{
		//Display requisition by RM ID
		
		requisitions = requisitionService.displayRequisitionByRM(rmId);		
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
		
	}
	
	public void displayAllRequisitions() throws OirsException 
	{
		//Display All requisitions	
		
		requisitions = requisitionService.displayAllRequisitions();
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
		
	}
	
	public void viewUndertakenRequisitions(String rmge_id) throws OirsException 
	{
		//Display undertaken requisition by a RMGE
		
		requisitions = requisitionService.viewUndertakenRequisitions(rmge_id);
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
		
	}
	
	public void viewRequisitionsByStatus(String employee_id,String status) throws OirsException 
	{
		// Display Requisition by Status of a RM
		
		requisitions = requisitionService.viewRequisitionsByStatus(employee_id,status);	
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
	}
	
	public void viewRequisitionsByDomain(String employee_id, String domain)	throws OirsException 
	{
		// Display requisitions by domain
		
		requisitions=requisitionService.viewRequisitionsByDomain(employee_id, domain);
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
	}
	
	public void viewRequisitionsBySkill(String employee_id, String skill) throws OirsException 
	{
		// Display Requisitions by skill
		
		requisitions=requisitionService.viewRequisitionsBySkill(employee_id, skill);
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
		
	}
	
	public void viewRequisitionsByProjectId(String employee_id, String projectId) throws OirsException 
	{
		// Display requisitions by Project ID
		
		requisitions=requisitionService.viewRequisitionsByProjectId(employee_id, projectId);
		if(requisitions.size()==0)
			System.out.println(IMessageMapper.ERROR_404);
		else
			displayReports(requisitions);
	}
	
	public void displayReports(ArrayList<Requisition> requisitions)
	{
		//Display UI for displaying in Formatted table view
		System.out.println("\nRequisition-ID\t  RM-ID\t  Project-ID\t      Date-Created\t\t    Date-Closed\t\t\tCurrent Status\t\tVaccancy Name\t\t\tSkill\t\tDomain\t\tNumber Required\t\tRMGE ID");
		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		for(Requisition r:requisitions)
		{
				System.out.format("\n    %-5s\t  %-5s\t     %-4s\t  %-25s\t%-25s\t    %-5s\t\t%-30s\t%-7s\t\t%-20s\t%-2d\t\t%s\n",r.getRequisition_id(),r.getRm_id(),r.getProject_id(),r.getDate_created(),r.getDate_closed(),r.getCurrent_status(),r.getVaccancy_name(),r.getSkill(),r.getDomain(),r.getNumber_required(),r.getRmge_id());
		}
	}

}
