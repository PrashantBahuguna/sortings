/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Project DAO Class 
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.oirs.exceptions.OirsException;

public class ProjectDAO implements IProjectDao{

	Connection con;
	PreparedStatement preparedStatement;
	static Logger log=Logger.getRootLogger();
	
	@Override
	public int closeProject(String projectId) throws OirsException {
		// Close a project that is release all the the EMP type employees from the project to RMG
		
		con=OirsDbUtil.getConnection();
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.CLOSE_PROJECT);
			preparedStatement.setString(1, projectId);
			return preparedStatement.executeUpdate();
			
			
		} catch (SQLException e) {
			log.error("Error while closing Project in the DB");
			throw new OirsException("Exception caused while closing project !! Invalid Project ID");
		}
		
	}

	@Override
	public String validateProject(String projectId) throws OirsException {
		// Check if the @param ProjectID is existing in the DB or not (validate)
		con=OirsDbUtil.getConnection();
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.GET_PROJECT);
			preparedStatement.setString(1, projectId);
			ResultSet rs =  preparedStatement.executeQuery();
			if(rs.next())
				return rs.getString(1);
			
		} catch (SQLException e) {
			log.error("Error while checking is Project is in the DB");
			throw new OirsException("Exception caused while validating project ID !! Invalid Project ID"+e.getMessage());
		}
		return null;
	}
	
}
