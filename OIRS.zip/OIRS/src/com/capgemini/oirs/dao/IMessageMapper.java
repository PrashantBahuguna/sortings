/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Message Mapping Interface 
 * 
 */
package com.capgemini.oirs.dao;

public interface IMessageMapper {
	
	final static String APP_START = "<<<<----APPLICATION START---->>>>";
	
	final static String LAST_ATTEMPT = "Last attempt !! Please enter valid credentials !!";
	
	final static String LOGIN_SUCCESSFUL = "\t\t<<< Login Successfull !! >>>";
	
	final static String ERROR_404 = "<<<<<<< NOTHING TO SHOW >>>>>>>\n<<<<<<< NO DATA FOUND >>>>>>>";


}
