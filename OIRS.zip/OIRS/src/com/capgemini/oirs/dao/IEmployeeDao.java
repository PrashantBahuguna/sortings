/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Employee DAO Interface 
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.dto.Project;
import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public interface IEmployeeDao {
	
	public abstract ArrayList<Employee> displayAllEmployee() throws SQLException;
	
	public abstract String getEmployeeId(String info) throws OirsException;
	public abstract String getEmployeePassword(String info) throws OirsException;
	public abstract String getEmployeeType(String username) throws OirsException;
	public abstract String getEmployeeName(String username) throws OirsException;
	public abstract Employee getEmployee(String username) throws OirsException;
	public abstract int setEmployeePassword(String username,String password) throws OirsException;
	public abstract String[] getHierarchy(String username) throws OirsException;
	public abstract ArrayList<Employee> viewResourcePool()throws OirsException;
	public abstract int updateProjectId(String projectId,ArrayList<String> emp_ids) throws OirsException;

	public abstract int addEmployee(Employee employee) throws OirsException;

	public abstract int generateEmployeeID() throws OirsException;

	public abstract int deleteEmployee(String emp_id) throws OirsException;

	public abstract int assignRole(String emp_id, String nEmp_type) throws OirsException;
	
	
	
	

}
