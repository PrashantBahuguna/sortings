/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Pool DAO Interface 
 * 
 */
package com.capgemini.oirs.dao;

import java.util.ArrayList;

import com.capgemini.oirs.dto.RequisitionPool;
import com.capgemini.oirs.exceptions.OirsException;

public interface IRequisitionPoolDAO {
	
	public abstract int initRequisitionPool(ArrayList<String> emp_ids) throws OirsException;
	public abstract ArrayList<RequisitionPool> viewRequisitionPool() throws OirsException;
	public abstract int clearRequisitionPool(String requisitionId) throws OirsException;
	public abstract int setRequisitionIds(ArrayList<String> emp_ids,String reqId) throws OirsException;
	public abstract ArrayList<RequisitionPool> viewRequisitionPoolById(String req_id) throws OirsException;
	public abstract ArrayList<String> getEmployeePool(String requisitionId) throws OirsException;

}
