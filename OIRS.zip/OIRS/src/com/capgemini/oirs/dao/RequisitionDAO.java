/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition DAO Class 
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public class RequisitionDAO implements IRequisitionDAO{
	
	
	private Connection connection;
	private PreparedStatement preparedStatement;
	static Logger log=Logger.getRootLogger();
	
	@Override
	public int generateRequisitionID() throws OirsException {
		//Generate the requisition ID from the sequence from database
		int id=0;
		
		connection = OirsDbUtil.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.GENERATE_REQUISITION_ID);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next())
			{
				id = rs.getInt(1);
				
			}
			log.info("Requisition ID generated");
			
		} catch (SQLException e) {
			log.error("Error while generating the requisition ID");
			System.out.println("Exception while retreiving SEQ_REQUISITION_ID <<<"+e.getMessage()+">>>");
			throw new OirsException();
		}
		
					
		return id;
	}
	
	@Override
	public String generateSysdate() throws OirsException {
		//Generates the SYSDATE from the database and send it to the calling object
		String date=null;
		
		connection = OirsDbUtil.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.GENERATE_SYSDATE);
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next())
			{
				date = rs.getString(1);
				System.err.println("DATE : "+date);
			}
			
			log.info("SYSDATE generated from the DB");
		} catch (SQLException e) {
			log.error("Error while generating the SYSDATE from DB");
			System.out.println("Exception while retreiving SYSDATE <<<"+e.getMessage()+">>>");
			throw new OirsException();
		}
					
		return date;
	}

	
	
	@Override
	public Requisition getRequisition(String id) throws OirsException {
		//Get @param username and return the Requisition class object (initialized) 
		
		Requisition requisition;
		String rm_id;
		String project_id;
		String date_created;
		String date_closed;
		String status;
		String vaccancy_name;
		String skill;
		String domain;
		int number_required;
		String rmge_id;
		connection = OirsDbUtil.getConnection();
		
		
		try {
			
			preparedStatement = connection.prepareStatement(IQueryMapper.GET_ALL_REQ_BY_ID);
			preparedStatement.setString(1, id);				
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) 
			{
				rm_id=rs.getString(2);
				project_id=rs.getString(3);
				date_created=rs.getString(4);
				date_closed=rs.getString(5);
				status=rs.getString(6);
				vaccancy_name=rs.getString(7);
				skill=rs.getString(8);
				domain=rs.getString(9);
				number_required=rs.getInt(10);
				rmge_id=rs.getString(11);
				
				requisition = new Requisition(id, rm_id, project_id, date_created, date_closed, status, vaccancy_name, skill, domain, number_required, rmge_id);
				
				
			}
					
			else 
			{
				requisition = new Requisition();
			}	
			
			log.info("Requisiton bean initialized from DB");
			
		} 
		catch (SQLException e) 
		{
			log.error("Error while initializing the Requisition bean from DB");
			System.err.println("Exception while getting Requisition Details : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		
		return requisition;
		
	}

	@Override
	public int raiseRequisition(Requisition requisition) throws OirsException {
		//Raise a requisition (By the RM) and insert it into the DB
		
		
		connection = OirsDbUtil.getConnection();
		
		
		try 
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_REQUISITION);
			preparedStatement.setString(1, requisition.getRequisition_id());
			preparedStatement.setString(2, requisition.getRm_id());
			preparedStatement.setString(3, requisition.getProject_id());
			
			preparedStatement.setString(4, "");
			preparedStatement.setString(5, requisition.getCurrent_status());
			preparedStatement.setString(6, requisition.getVaccancy_name());
			preparedStatement.setString(7, requisition.getSkill());
			preparedStatement.setString(8, requisition.getDomain());
			preparedStatement.setInt(9, requisition.getNumber_required());
			preparedStatement.setString(10, requisition.getRmge_id());
			log.info("Requisition raised in the DB");
			return preparedStatement.executeUpdate();
			
		} catch (SQLException e) 
		{
			log.error("Error while raising requisiion in DB");
			System.err.println("Exception while raising requisition : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		
		
		
	}

	@Override
	public ArrayList<Requisition> getRequisitionByRM(String rm_id) throws OirsException {
		//Get @param rm_id and return the Requisition class object (initialized) 
		
				
				ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
				String requisition_id;
				String project_id;
				String date_created;
				String date_closed;
				String status;
				String vaccancy_name;
				String skill;
				String domain;
				int number_required;
				String rmge_id;
				connection = OirsDbUtil.getConnection();
				
				
				try {
					
					preparedStatement = connection.prepareStatement(IQueryMapper.GET_REQ_BY_RMID);
					preparedStatement.setString(1, rm_id);				
					ResultSet rs = preparedStatement.executeQuery();
					while (rs.next()) 
					{
						Requisition requisition;
						requisition_id=rs.getString(1);
						project_id=rs.getString(3);
						date_created=rs.getString(4);
						date_closed=rs.getString(5);
						status=rs.getString(6);
						vaccancy_name=rs.getString(7);
						skill=rs.getString(8);
						domain=rs.getString(9);
						number_required=rs.getInt(10);
						rmge_id=rs.getString(11);
						
						requisition = new Requisition(requisition_id, rm_id, project_id, date_created, date_closed, status, vaccancy_name, skill, domain, number_required, rmge_id);
						requisitions.add(requisition);
					}
							
					log.info("Requisition.get from the DB");
					
				} 
				catch (SQLException e) 
				{
					log.error("Error while getting requisition fomr the DB");
					System.err.println("Exception while getting Requisition By RM ID : << " + e.getMessage() + " >>");
					throw new OirsException();
				}
				
				return requisitions;
	}

	@Override
	public ArrayList<Requisition> getAllRequisitions() throws OirsException {
		//Return the Requisition array class object (initialized) 
		
		
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		String requisition_id;
		String rm_id;
		String project_id;
		String date_created;
		String date_closed;
		String status;
		String vaccancy_name;
		String skill;
		String domain;
		int number_required;
		String rmge_id;
		
		
		connection = OirsDbUtil.getConnection();
		
	
		try {
			
			preparedStatement = connection.prepareStatement(IQueryMapper.GET_ALL_REQUISITION);
			
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) 
			{
				Requisition requisition;
				requisition_id=rs.getString(1);
				rm_id=rs.getString(2);
				project_id=rs.getString(3);
				date_created=rs.getString(4);
				date_closed=rs.getString(5);
				status=rs.getString(6);
				vaccancy_name=rs.getString(7);
				skill=rs.getString(8);
				domain=rs.getString(9);
				number_required=rs.getInt(10);
				rmge_id=rs.getString(11);
				
				requisition = new Requisition(requisition_id, rm_id, project_id, date_created, date_closed, status, vaccancy_name, skill, domain, number_required, rmge_id);
				requisitions.add(requisition);
			}
			
			log.info("Requisition.getAll from the DB");
			
		} 
		catch (SQLException e) 
		{
			log.error("Error Requisition.getAll from the DB");
			System.err.println("Exception while getting All Requisition : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		
		
		return requisitions;
		
	}

	@Override
	public int undertakeRequisition(String requisition_id,String rmge_id) throws OirsException {
	//Undertake a requisition based on @param.requisition_id and @param.rmgeid	
		connection = OirsDbUtil.getConnection();
		
		
		try 
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_REQ_RMGEID_BY_REQID);
			preparedStatement.setString(1, rmge_id);
			preparedStatement.setString(2, requisition_id);
			log.info("Requisition.undertakeRequisition from the DB Done");
			return preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			log.error("Error while undertaking the requisition from the DB");
			System.err.println("Exception while undertaking Requisition : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		
	}

	@Override
	public ArrayList<Requisition> getUndertakenRequisitions(String rmge_id) throws OirsException {
	//Get the undertaken requisitions of a RMGE by his ID	
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		String requisition_id;
		String rm_id;
		String project_id;
		String date_created;
		String date_closed;
		String status;
		String vaccancy_name;
		String skill;
		String domain;
		int number_required;
	
		
		
		connection = OirsDbUtil.getConnection();
		
		try {
			
			preparedStatement = connection.prepareStatement(IQueryMapper.GET_REQ_BY_RMGEID);
			preparedStatement.setString(1, rmge_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) 
			{
				Requisition requisition;
				requisition_id=rs.getString(1);
				rm_id=rs.getString(2);
				project_id=rs.getString(3);
				date_created=rs.getString(4);
				date_closed=rs.getString(5);
				status=rs.getString(6);
				vaccancy_name=rs.getString(7);
				skill=rs.getString(8);
				domain=rs.getString(9);
				number_required=rs.getInt(10);
				rmge_id=rs.getString(11);
				
				requisition = new Requisition(requisition_id, rm_id, project_id, date_created, date_closed, status, vaccancy_name, skill, domain, number_required, rmge_id);
				requisitions.add(requisition);
			}		
			
			log.info("Get undertaken requisitions done");
		} 
		catch (SQLException e) 
		{
			log.error("Error while getting the undertaken requisitions");
			System.err.println("Exception while getting RMGE's Undertaken Requisitions : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		
		
		return requisitions;
		
		
	}

	@Override
	public int getResourcesRequired(String reqId) throws OirsException {
	// Get the resources required against a requisition by ID
		
		

		connection = OirsDbUtil.getConnection();
		
		
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.GET_REQ_VACCANCY);
			preparedStatement.setString(1, reqId);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next())
				return rs.getInt(1);
			log.info("Resources retreived from DB");
			
			
		} catch (SQLException e) {
			log.error("Error while getting no of resources frrom DB");
			throw new OirsException("Exception caused while retrieving number required for the requisition "+e.getMessage());
		}
		
		return 0;
	}

	@Override
	public String getProjectId(String requisitionId) throws OirsException {
		// Get project ID corresponding to a requisition by ID
		
		
		connection = OirsDbUtil.getConnection();
		try 
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.GET_REQ_PROJECTID_BY_REQID);
			preparedStatement.setString(1, requisitionId);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next())
				return rs.getString(1);
			
		} catch (SQLException e) 
		{
			throw new OirsException("Exception raised while retrieving Project ID ");
		}
		return null;
	}

	@Override
	public int acceptRequisition(String requisitionId, String employee_id) throws OirsException {
		// Accept a requisition i.e set the Close Date of project and set Status = Closed
		
		
		String status = "CLOSED";
		
		
		connection = OirsDbUtil.getConnection();
		try 
		{
			PreparedStatement preparedStatement1 = connection.prepareStatement(IQueryMapper.UPDATE_REQ_DATE_CLOSED);
			preparedStatement1.setString(1, employee_id);
			preparedStatement1.setString(2, requisitionId);
			int ret = preparedStatement1.executeUpdate();
			System.out.println("Closing Date of requisition is updated !!! ");
			
			PreparedStatement preparedStatement2 = connection.prepareStatement(IQueryMapper.UPDATE_REQ_STATUS_CLOSED);
			preparedStatement2.setString(1, status);
			preparedStatement2.setString(2, employee_id);
			preparedStatement2.setString(3, requisitionId);
			ret += preparedStatement2.executeUpdate();
			System.out.println("Requisition Sucessfully Closed !!");
			
			return ret;
		} catch (SQLException e) 
		{
			throw new OirsException("Exception caused while processing the Accept Requisition ");
		}
		
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByStatus(String employee_id,String status) throws OirsException {
		// Get all the requisitions under a RM by Status
		
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		Requisition requisition;
		connection = OirsDbUtil.getConnection();
		try {
			
			if(employee_id.contains("RMGE"))
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_STATUS_X);
			else
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_STATUS);
			
			preparedStatement.setString(1, status);
			preparedStatement.setString(2, employee_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				requisition = new Requisition();
				requisition.setRequisition_id(rs.getString(1));
				requisition.setRm_id(rs.getString(2));
				requisition.setProject_id(rs.getString(3));
				requisition.setDate_created(rs.getString(4));
				requisition.setDate_closed(rs.getString(5));
				requisition.setCurrent_status(rs.getString(6));
				requisition.setVaccancy_name(rs.getString(7));
				requisition.setSkill(rs.getString(8));
				requisition.setDomain(rs.getString(9));
				requisition.setNumber_required(rs.getInt(10));
				requisition.setRmge_id(rs.getString(11));
				requisitions.add(requisition);
			}
			
			return requisitions;
			
		} catch (Exception e) {
			throw new OirsException("Exception caused while diaplying OPEN/CLOSED Requisitions");
		}
		
		
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByDomain(String employee_id, String domain)	throws OirsException {
		// Get all the requisitions under a RM by Domain
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		Requisition requisition;
		connection = OirsDbUtil.getConnection();
		try {

			if(employee_id.contains("RMGE"))
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_DOMAIN_X);
			else
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_DOMAIN);
			
			preparedStatement.setString(1, domain);
			preparedStatement.setString(2, employee_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				requisition = new Requisition();
				requisition.setRequisition_id(rs.getString(1));
				requisition.setRm_id(rs.getString(2));
				requisition.setProject_id(rs.getString(3));
				requisition.setDate_created(rs.getString(4));
				requisition.setDate_closed(rs.getString(5));
				requisition.setCurrent_status(rs.getString(6));
				requisition.setVaccancy_name(rs.getString(7));
				requisition.setSkill(rs.getString(8));
				requisition.setDomain(rs.getString(9));
				requisition.setNumber_required(rs.getInt(10));
				requisition.setRmge_id(rs.getString(11));
				requisitions.add(requisition);
			}
			
			return requisitions;
			
		} catch (Exception e) {
			throw new OirsException("Exception caused while viewing requistions by domain !!" +e.getMessage());
		}
		
		
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsBySkill(String employee_id, String skill) throws OirsException {
		// Get all the requisitions under a RM by Skill
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		Requisition requisition;
		connection = OirsDbUtil.getConnection();
		try {
			
			if(employee_id.contains("RMGE"))
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_SKILL_X);
			else
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_SKILL);
			
			preparedStatement.setString(1, skill);
			preparedStatement.setString(2, employee_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				requisition = new Requisition();
				requisition.setRequisition_id(rs.getString(1));
				requisition.setRm_id(rs.getString(2));
				requisition.setProject_id(rs.getString(3));
				requisition.setDate_created(rs.getString(4));
				requisition.setDate_closed(rs.getString(5));
				requisition.setCurrent_status(rs.getString(6));
				requisition.setVaccancy_name(rs.getString(7));
				requisition.setSkill(rs.getString(8));
				requisition.setDomain(rs.getString(9));
				requisition.setNumber_required(rs.getInt(10));
				requisition.setRmge_id(rs.getString(11));
				requisitions.add(requisition);
			}
			
			return requisitions;
			
		} catch (Exception e) {
			throw new OirsException("Exception caused while viewing requistions by Skill !!" +e.getMessage());
		}
	}

	@Override
	public ArrayList<Requisition> viewRequisitionsByProjectId(String employee_id, String projectId) throws OirsException {
		// Get all the requisitions under a RM by Project ID
		ArrayList<Requisition> requisitions = new ArrayList<Requisition>();
		Requisition requisition;
		connection = OirsDbUtil.getConnection();
		try {

			if(employee_id.contains("RMGE"))
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_PROJECTID_X);
			else
				preparedStatement = connection.prepareStatement(IQueryMapper.VIEW_REQ_BY_PROJECTID);
			
			preparedStatement.setString(1, projectId);
			preparedStatement.setString(2, employee_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				requisition = new Requisition();
				requisition.setRequisition_id(rs.getString(1));
				requisition.setRm_id(rs.getString(2));
				requisition.setProject_id(rs.getString(3));
				requisition.setDate_created(rs.getString(4));
				requisition.setDate_closed(rs.getString(5));
				requisition.setCurrent_status(rs.getString(6));
				requisition.setVaccancy_name(rs.getString(7));
				requisition.setSkill(rs.getString(8));
				requisition.setDomain(rs.getString(9));
				requisition.setNumber_required(rs.getInt(10));
				requisition.setRmge_id(rs.getString(11));
				requisitions.add(requisition);
			}
			
			return requisitions;
			
		} catch (Exception e) {
			throw new OirsException("Exception caused while viewing requistions by project ID !!" +e.getMessage());
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	 
}
