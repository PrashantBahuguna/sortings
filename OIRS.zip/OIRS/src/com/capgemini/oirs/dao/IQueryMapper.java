/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Query Mapper Interface 
 * 
 */
package com.capgemini.oirs.dao;

public interface IQueryMapper {
	
	
	//To be implemented
	//Shifting the queries from classes here.
	
	//----------------------------------------EmployeeDAO----------------------------------------
	
	final static String GET_EMP_TABLE = "SELECT * FROM Employee";
	
	final static String GET_ALL_EMP_BY_ID = "SELECT * FROM Employee WHERE Employee_Id = ?";
	
	final static String UPDATE_EMP_PASSWORD = "UPDATE Employee SET Password = ? WHERE Employee_Id = ?";
	
	final static String GET_ALL_REQ_BY_PROJECTID = "SELECT * FROM Requisition WHERE project_id = ?";
	
	final static String GET_ALL_ONBENCH_EMP = "SELECT * FROM EMPLOYEE WHERE Project_Id = 'RMG' AND Emp_Type = 'EMP'";
	
	final static String UPDATE_EMP_PROJECTID_BY_EMPID = "UPDATE Employee SET Project_Id = ? WHERE Employee_Id = ?";
	
	final static String GENERATE_EMP_ID = "SELECT emp_id_seq.NEXTVAL FROM DUAL";
	
	final static String INSERT_EMP = "INSERT INTO Employee VALUES (?,?,?,?,?,?,?,?)";
	
	final static String DELETE_EMP_BY_EMPID = "DELETE FROM Employee WHERE Employee_Id = ?";
	
	final static String UPDATE_EMP_EMP_TYPE = "UPDATE Employee SET Emp_Type = ? WHERE Employee_Id = ?";
	
	
	
	
	
	//----------------------------------------RequisitionDAO----------------------------------------
	
	final static String GENERATE_REQUISITION_ID = "SELECT seq_requisition.NEXTVAL FROM DUAL";
	
	final static String GENERATE_SYSDATE = "SELECT SYSDATE FROM DUAL";
	
	final static String GET_ALL_REQ_BY_ID = "SELECT * FROM Requisition WHERE Requisition_Id = ?";
	
	final static String INSERT_REQUISITION = "INSERT INTO Requisition VALUES(?,?,?,SYSDATE,?,?,?,?,?,?,?)";
	
	final static String GET_REQ_BY_RMID = "SELECT * FROM Requisition WHERE Rm_Id = ?";
	
	final static String GET_ALL_REQUISITION = "SELECT * FROM Requisition";
	
	final static String UPDATE_REQ_RMGEID_BY_REQID = "UPDATE Requisition SET Rmge_id = ? WHERE Requisition_id = ?";
	
	final static String GET_REQ_BY_RMGEID = "SELECT * FROM Requisition WHERE Rmge_Id=?";
	
	final static String GET_REQ_VACCANCY = "SELECT Number_Required FROM Requisition WHERE Requisition_Id = ?";
	
	final static String GET_REQ_PROJECTID_BY_REQID = "SELECT Project_Id FROM Requisition WHERE Requisition_Id = ?";
	
	final static String UPDATE_REQ_DATE_CLOSED = "UPDATE Requisition SET Date_Closed = SYSDATE WHERE RM_ID = ? AND Requisition_Id = ?";
	
	final static String UPDATE_REQ_STATUS_CLOSED = "UPDATE Requisition SET Current_Status = ? WHERE RM_ID = ? AND Requisition_Id = ?";
	
	final static String VIEW_REQ_BY_STATUS = "SELECT * FROM Requisition WHERE Current_Status = ? AND Rm_Id = ?";
	
	final static String VIEW_REQ_BY_DOMAIN = "SELECT * FROM Requisition WHERE Domain = ? AND Rm_Id = ?";
	
	final static String VIEW_REQ_BY_SKILL = "SELECT * FROM Requisition WHERE Skill = ? AND Rm_Id = ?";
	
	final static String VIEW_REQ_BY_PROJECTID = "SELECT * FROM Requisition WHERE Project_Id = ? AND Rm_Id = ?";
	
	final static String VIEW_REQ_BY_STATUS_X = "SELECT * FROM Requisition WHERE Current_Status = ? AND Rmge_Id = ?";
	
	final static String VIEW_REQ_BY_SKILL_X = "SELECT * FROM Requisition WHERE Skill = ? AND Rmge_Id = ?";
	
	final static String VIEW_REQ_BY_DOMAIN_X = "SELECT * FROM Requisition WHERE Domain = ? AND Rmge_Id = ?";
	
	final static String VIEW_REQ_BY_PROJECTID_X = "SELECT * FROM Requisition WHERE PROJECT_ID = ? AND Rmge_Id = ?";
	
	
	//----------------------------------------RequisitionDAO----------------------------------------
	
	final static String INSERT_REQ_POOL = "INSERT INTO Requisition_Pool (employee_id,employee_name,skill,domain,experience) "
			+ "SELECT employee_id,name,skill,domain,experience FROM Employee e where e.employee_id=?";
	
	final static String UPDATE_REQ_POOL = "UPDATE Requisition_Pool SET Requisition_Id = ? WHERE Employee_Id = ?";
	
	final static String GET_ALL_REQ_POOL = "SELECT * FROM Requisition_Pool";
	
	final static String GET_REQ_POOL_BY_REQID = "SELECT * FROM Requisition_Pool WHERE Requisition_Id = ?";
	
	final static String CLEAR_REQ_POOL = "DELETE FROM Requisition_Pool WHERE Requisiton_Id = ?";
	
	final static String GET_REQ_EMPID = "SELECT Employee_Id FROM Requisition_Pool WHERE Requisition_Id = ?";
	

	//----------------------------------------ProjectDAO----------------------------------------
	
	
	final static String CLOSE_PROJECT = "UPDATE Employee SET Project_Id = 'RMG' WHERE Project_Id = ? AND Emp_Type = 'EMP'";
	
	final static String GET_PROJECT = "SELECT Project_Id FROM Project WHERE Project_Id = ?";
	
	
	
	
	
	
	
	
	
	
	
	

}
