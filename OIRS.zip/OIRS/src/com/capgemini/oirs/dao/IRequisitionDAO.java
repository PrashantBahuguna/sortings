/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition DAO Interface 
 * 
 */
package com.capgemini.oirs.dao;

import java.util.ArrayList;

import com.capgemini.oirs.dto.Requisition;
import com.capgemini.oirs.exceptions.OirsException;

public interface IRequisitionDAO {
	
	public abstract int generateRequisitionID() throws OirsException;
	public abstract int raiseRequisition(Requisition requisition) throws OirsException;
	
	public abstract String generateSysdate() throws OirsException;
	public abstract Requisition getRequisition(String username) throws OirsException;
	public abstract ArrayList<Requisition> getRequisitionByRM(String rm_id) throws OirsException;
	public abstract ArrayList<Requisition> getAllRequisitions() throws OirsException;
	public abstract int undertakeRequisition(String requisition_id,String rmge_id) throws OirsException;
	public abstract ArrayList<Requisition> getUndertakenRequisitions(String rmge_id) throws OirsException;
	public abstract int getResourcesRequired (String reqId) throws OirsException;
	public abstract String getProjectId(String requisitionId) throws OirsException;
	public abstract int acceptRequisition(String requisitionId, String employee_id) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByStatus(String employee_id,String status) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByDomain(String employee_id, String domain) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsBySkill(String employee_id, String skill) throws OirsException;
	public abstract ArrayList<Requisition> viewRequisitionsByProjectId(String employee_id, String projectId) throws OirsException;
	
}
