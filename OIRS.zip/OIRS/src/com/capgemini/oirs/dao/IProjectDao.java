/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Project DAO Interface 
 * 
 */
package com.capgemini.oirs.dao;

import java.io.Closeable;

import com.capgemini.oirs.exceptions.OirsException;

public interface IProjectDao {
	
	public abstract int closeProject(String projectId) throws OirsException;
	
	public abstract String validateProject(String projectId) throws OirsException;

}
