/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Requisition Pool DAO Class 
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.oirs.dto.RequisitionPool;
import com.capgemini.oirs.exceptions.OirsException;

public class RequisitionPoolDAO implements IRequisitionPoolDAO{
	
	
	Connection con;
	PreparedStatement preparedStatement;
	

	@Override
	public int initRequisitionPool(ArrayList<String> emp_ids) throws OirsException {
		// Initialize the requisition pool i.e add employees @param to the requisition pool table
		
		con = OirsDbUtil.getConnection();
		int ret=0;
		try 
		{
			for(String id:emp_ids)
			{
				preparedStatement = con.prepareStatement(IQueryMapper.INSERT_REQ_POOL);
				preparedStatement.setString(1, id);
				ret = preparedStatement.executeUpdate();
				
			}
			return ret;
			
		} catch (SQLException e) {
			throw new OirsException("Exception while initializing Requisition Pool DB");
		}
		
	}
	
	@Override
	public int setRequisitionIds(ArrayList<String> emp_ids, String reqId) throws OirsException {		
		//set the requisiton_id where emp_id = @param.emp_ids and requisition id = @param.reqId
		
		con = OirsDbUtil.getConnection();
		int ret=0;
		try 
		{
			for(String id:emp_ids)
			{
				
				preparedStatement = con.prepareStatement(IQueryMapper.UPDATE_REQ_POOL);
				
				preparedStatement.setString(1, reqId);
				
				preparedStatement.setString(2, id);
				
				ret = preparedStatement.executeUpdate();
				
				
			}
			
			return ret;
			
			
		} catch (SQLException e) {
			throw new OirsException("Exception while updating the Requisition ID in  Requisition Pool DB "+e.getMessage());
			
		}
			
	}

	@Override
	public ArrayList<RequisitionPool> viewRequisitionPool() throws OirsException {
		// Retrieve all the RequisitionPool table and return the list
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		
		con = OirsDbUtil.getConnection();
		
		String employee_id;
		String employee_name;
		String skill;
		String domain;
		int experience;
		String requisition_id;
		
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.GET_ALL_REQ_POOL);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				RequisitionPool requisitionPool = new RequisitionPool();
				employee_id = rs.getString(1);
				employee_name = rs.getString(2);
				skill = rs.getString(3);
				domain = rs.getString(4);
				experience = rs.getInt(5);
				requisition_id=rs.getString(6);
				requisitionPool = new RequisitionPool(employee_id, employee_name, skill, domain, experience,requisition_id);
				requisitionPools.add(requisitionPool);
				
			}
			
		} catch (SQLException e) {
			throw new OirsException("Exception caused while retreiving the Requisition Pool ");
		}			
		
		return requisitionPools;
	}
	
	
	@Override
	public ArrayList<RequisitionPool> viewRequisitionPoolById(String req_id) throws OirsException {
		// Retrieve the Requisition Pool by Requisition ID and send the list
		ArrayList<RequisitionPool> requisitionPools = new ArrayList<RequisitionPool>();
		
		con = OirsDbUtil.getConnection();
		
		String employee_id;
		String employee_name;
		String skill;
		String domain;
		int experience;
		String requisition_id;
		
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.GET_REQ_POOL_BY_REQID);
			preparedStatement.setString(1, req_id);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				RequisitionPool requisitionPool = new RequisitionPool();
				employee_id = rs.getString(1);
				employee_name = rs.getString(2);
				skill = rs.getString(3);
				domain = rs.getString(4);
				experience = rs.getInt(5);
				requisition_id=rs.getString(6);
				requisitionPool = new RequisitionPool(employee_id, employee_name, skill, domain, experience,requisition_id);
				requisitionPools.add(requisitionPool);
				
			}
			
		} catch (SQLException e) {
			throw new OirsException("Exception caused while retreiving the Requisition Pool by ID ");
		}			
		
		return requisitionPools;
	}

	@Override
	public int clearRequisitionPool(String requisitionId) throws OirsException {
		//Clear the requisition pool table
		
		con = OirsDbUtil.getConnection();
		
		try 
		{
			preparedStatement = con.prepareStatement(IQueryMapper.CLEAR_REQ_POOL);
			preparedStatement.setString(1, requisitionId);
			return preparedStatement.executeUpdate();
			//will return 0 if table successfully truncated
		} catch (SQLException e) {
			throw new OirsException("Exception while clearing Requisition Table "+e.getMessage());
		}		
	}

	@Override
	public ArrayList<String> getEmployeePool(String requisitionId) throws OirsException {
		// Get all employee Ids from requisition pool where requisition Id = @param
		
		ArrayList<String> emp_ids = new ArrayList<String>();
		
		con = OirsDbUtil.getConnection();
		try 
		{
			preparedStatement = con.prepareStatement(IQueryMapper.GET_REQ_EMPID);
			preparedStatement.setString(1, requisitionId);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				emp_ids.add(rs.getString(1));
			}
			return emp_ids;
			
		} catch (SQLException e) 
		{
			throw new OirsException("Exception caused while retrieving Employee Ids of requisition");
		}	
		
		
	}

	

	

}
