/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Database Util Connection Class
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.oirs.exceptions.OirsException;

//import org.apache.log4j.Logger;



public class OirsDbUtil {

	static Connection con;
	static Logger log=Logger.getRootLogger();
	//Create a static database connection
	public static Connection getConnection() throws OirsException 
	{
		
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg220","training220");
			log.info("Database conncetion successful..!!");
			
		} catch (SQLException e) {
			log.error("Database Connection Issue..!!");
			throw new OirsException("Error in database connection"+e.getMessage());
		}
		
		return con;		
	}
	
}
