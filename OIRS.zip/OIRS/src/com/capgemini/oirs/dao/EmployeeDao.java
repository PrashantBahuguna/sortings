/**
 * Project Name : Online Internal Recruitment System (OIRS)
 * Made By : Prashant Bahuguna
 * EMP ID : 155251
 * Created On : 06/08/2018
 * Version : 1.0
 * Last Updated : 08/09/2018
 * Description : Employee DAO Class 
 * 
 */
package com.capgemini.oirs.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.oirs.dto.Employee;
import com.capgemini.oirs.exceptions.OirsException;

/**
 * @author pbahugun
 *
 */
public class EmployeeDao implements IEmployeeDao {

	private Connection connection;	
	private Statement stmt;
	private PreparedStatement pstmt;
	static Logger log=Logger.getRootLogger();

	@Override
	public ArrayList<Employee> displayAllEmployee() throws SQLException {
	//Retrieve all the details of all the employees in Employee table and return the list
		
		ArrayList<Employee> al = new ArrayList<Employee>();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg220",
				"training220");
		stmt = con.createStatement();
	
		ResultSet rs = stmt.executeQuery(IQueryMapper.GET_EMP_TABLE);
		while (rs.next()) {
			Employee e = new Employee();
			e.setEmployee_id(rs.getString(1));
			e.setPassword(rs.getString(2));
			e.setName(rs.getString(3));
			e.setProject_id(rs.getString(4));
			e.setSkill(rs.getString(5));
			e.setDomain(rs.getString(6));
			e.setExperience(rs.getInt(7));
			e.setEmp_type(rs.getString(8));
			al.add(e);
		}
		return al;
	}

	

	// Get employee id using @param username from the user and validate if it exists in the DB
	@Override
	public String getEmployeeId(String info) throws OirsException {
		connection = OirsDbUtil.getConnection();
		
		String x;
		try {
			
			pstmt = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
			pstmt.setString(1, info);
			
			
			ResultSet rs = pstmt.executeQuery();
			

			if (rs.next()) 
			{
				//rs.next(); 					// resultset.next() was not called
				x = rs.getString(1);
				log.info("User found in DB");
			} 
			else 
			{
				System.err.println("Username does not exist!!");
				log.error("User does not exist");
				x = null;
			}
		} catch (SQLException e) 
		{
			log.error("Error while getting emp_id");
			System.err
					.println("Exception while getting Employee ID : << " + e.getMessage() + " >>");
			throw new OirsException();
		}
		return x;

	}
	
		// Get @param username from the user and retrieve the corresponding password from the DB
		@Override
		public String getEmployeePassword(String info) throws OirsException {
			
			connection = OirsDbUtil.getConnection();
			
			String x;
			try {
				
				pstmt = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				pstmt.setString(1, info);				
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) 
				{					
					x = rs.getString(2);
					log.info("User's password found in DB");
					
				} 
				else 
				{					
					x = null;
					log.error("Password not found");
				}
			} 
			catch (SQLException e) 
			{
				log.error("Error while getting Password");
				System.err.println("Exception while getting Employee password : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			return x;

		}

		@Override
		public String getEmployeeType(String username) throws OirsException {
			//Get @param username from the user and return it's return employee_type
			String type;
			connection = OirsDbUtil.getConnection();
			
			try {
				
				pstmt = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				pstmt.setString(1, username);				
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) 
					type = rs.getString(8);			
				else 
					type = null;
				
				log.info("EMP_TYPE retreived !!!");
				
			} 
			catch (SQLException e) 
			{
				log.error("Error while retreiving emp_type");
				System.err.println("Exception while getting Employee type : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			return type;
		}

		@Override
		public String getEmployeeName(String username) throws OirsException {
		//Get @param username from the user and return the username	
			
			String name;
			connection = OirsDbUtil.getConnection();
			
			try {
				
				pstmt = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				pstmt.setString(1, username);				
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) 
					name = rs.getString(3);			
				else 
					name = null;
				
				log.info("Employee name retreived");
			} 
			catch (SQLException e) 
			{
				log.error("Error while retreiving employee name");
				System.err.println("Exception while getting Employee name : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			return name;
		}

		@Override
		public Employee getEmployee(String username) throws OirsException {
			//Get @param username and return the Employee class object (initialized)
			Employee employee = null;
			String employee_id =null;
			String password=null;
			String name=null;
			String project_id=null;
			String skill=null;
			String domain=null;
			int experience=0;
			String employee_type=null;
			connection = OirsDbUtil.getConnection();
			
			try {
				
				pstmt = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				pstmt.setString(1, username);				
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) 
				{
					employee_id = rs.getString(1);
					password = rs.getString(2);
					name = rs.getString(3);
					project_id = rs.getString(4);
					skill = rs.getString(5);
					domain = rs.getString(6);
					experience = rs.getInt(7);
					employee_type = rs.getString(8);
					employee = new Employee(employee_id, password, name, project_id, skill, domain, experience, employee_type);
					
					log.info("Employee bean initialized successfully!!");
				}
						
				else 
				{
					employee = new Employee();
				}					
				
			} 
			catch (SQLException e) 
			{
				log.error("Error while initializing the employee bean");
				System.err.println("Exception while getting Employee details : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			
			return employee;
		}

		@Override
		public int setEmployeePassword(String username,String password) throws OirsException 
		{
			//Get @param username and @param password and update the DB with it
			connection = OirsDbUtil.getConnection();
			
			try {
				
				pstmt = connection.prepareStatement(IQueryMapper.UPDATE_EMP_PASSWORD);				
				pstmt.setString(1, password);
				pstmt.setString(2, username);
				log.info("Password updated !!");
				return pstmt.executeUpdate();			
				
			} 
			catch (SQLException e) 
			{
				log.error("Error while updating the password");
				System.err.println("Exception while getting Employee name : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			
	
		}

		@Override
		public String[] getHierarchy(String username) throws OirsException 
		{
			//Implementations of various queries required to retrieve the hierarchy of a particular employee
			
			connection = OirsDbUtil.getConnection();
			String[] hierarchy={"",""};
			String project_id = null;
			
		
			
			PreparedStatement preparedStatement1;
			PreparedStatement preparedStatement2;
			PreparedStatement preparedStatement3;
			try 
			{
				preparedStatement1 = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				preparedStatement1.setString(1, username);
				ResultSet rs1 = preparedStatement1.executeQuery();
				if(rs1.next())
					project_id = rs1.getString(4);
				
				preparedStatement2 = connection.prepareStatement(IQueryMapper.GET_ALL_REQ_BY_PROJECTID);
				preparedStatement2.setString(1, project_id);
				ResultSet rs2 = preparedStatement2.executeQuery();
				if(rs2.next())
					hierarchy[0] = rs2.getString("RM_ID");
					
				preparedStatement3 = connection.prepareStatement(IQueryMapper.GET_ALL_EMP_BY_ID);
				preparedStatement3.setString(1, hierarchy[0]);
				ResultSet rs3 = preparedStatement3.executeQuery();
				if(rs3.next())
					hierarchy[1] = rs3.getString("NAME");
				
				log.info("Hierarchy retreived !!");
				
			} catch (SQLException e) 
			{
				log.error("Error while retreiving the employee hierarchy");
				System.err.println("Exception while getting Employee hierarchy : << " + e.getMessage() + " >>");
				throw new OirsException();
			}
			
			return hierarchy;
		}

		@Override
		public ArrayList<Employee> viewResourcePool() throws OirsException {
			// Display the requisition pool i.e Requisition_Pool table
			connection = OirsDbUtil.getConnection();
			
			PreparedStatement preparedStatement;
			ArrayList<Employee> employees = new ArrayList<Employee>();
			
			try {
				preparedStatement = connection.prepareStatement(IQueryMapper.GET_ALL_ONBENCH_EMP);
				ResultSet rs = preparedStatement.executeQuery();
				while(rs.next())
				{
					Employee employee = new Employee(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8));
					employees.add(employee);
				}
				log.info("Resource pool retreived");
				
			} catch (SQLException e) {
				log.error("Error while retreiving the resource pool");
				throw new OirsException("Exception caused while retreiving the resources for requisition !! ");
			}
			
			return employees;
		}



		@Override
		public int updateProjectId(String projectId,ArrayList<String> emp_ids) throws OirsException {
			// Update project-ID of all employees in list emp_ids
			
			connection = OirsDbUtil.getConnection();
			int ret=0;
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_EMP_PROJECTID_BY_EMPID);
				preparedStatement.setString(1, projectId);
				for(String emp_id : emp_ids)
				{
					preparedStatement.setString(2, emp_id);
					ret = preparedStatement.executeUpdate();
				}
				System.out.println("Resources successfully allocated to respective projects !!");
				log.info("Project ID updated !!");
				return ret;
			} 
			catch (SQLException e) 
			{
				log.error("Error while updating the prooject ID");
				throw new OirsException("Exception caused while updating the project ids of employees ");
			}
			
		}

		@Override
		public int generateEmployeeID() throws OirsException {
			//Generate the employee ID from the sequence from database
			int id=0;
			
			connection = OirsDbUtil.getConnection();
			PreparedStatement preparedStatement;
			try {
				preparedStatement = connection.prepareStatement(IQueryMapper.GENERATE_EMP_ID);
				ResultSet rs = preparedStatement.executeQuery();
				if(rs.next())
				{
					id = rs.getInt(1);
					
				}
			} catch (SQLException e) {
				
				log.error("Error while generating the EMP ID");
				throw new OirsException("Exception while retreiving EMPLOYEE_ID_SEQ <<<"+e.getMessage()+">>>");
			}
			log.info("EMP ID generated");
			return id;
		}

		@Override
		public int addEmployee(Employee employee) throws OirsException {
			// Add new Employee to the DB		
			
			String emp_id=null;
			if("EMP".equals(employee.getEmp_type()))
				emp_id = "E0"+generateEmployeeID();
			else if("RM".equals(employee.getEmp_type()))
				emp_id = "RM"+generateEmployeeID();
			else if("RMGE".equals(employee.getEmp_type()))
				emp_id = "RMGE"+generateEmployeeID();
			
			connection = OirsDbUtil.getConnection();
			try 
			{
				PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_EMP);
				preparedStatement.setString(1, emp_id);
				preparedStatement.setString(2, employee.getPassword());
				preparedStatement.setString(3, employee.getName());
				preparedStatement.setString(4, employee.getProject_id());
				preparedStatement.setString(5, employee.getSkill());
				preparedStatement.setString(6, employee.getDomain());
				preparedStatement.setInt(7, employee.getExperience());
				preparedStatement.setString(8, employee.getEmp_type());
				int ret = preparedStatement.executeUpdate();
				
				log.info("Empolyee added to DB");
				
				return ret;
				
			} catch (SQLException e) {
				log.error("Error while adding employee to DB");
				throw new OirsException("Exception while adding employee to DB <<<"+e.getMessage()+">>>");
			}
			
			
		}



		@Override
		public int deleteEmployee(String emp_id) throws OirsException {
			// Delete employee from DB by ID
			
			connection = OirsDbUtil.getConnection();
			try 
			{
				PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DELETE_EMP_BY_EMPID);
				preparedStatement.setString(1, emp_id);
				int ret = preparedStatement.executeUpdate();
				log.info("Employee Deleted");
				return ret;
			} catch (SQLException e) {
				log.error("Error while adding employee to DB");
				throw new OirsException("Exception while deleting employee from DB <<<"+e.getMessage()+">>>");
			}
			
		}



		@Override
		public int assignRole(String emp_id, String nEmp_type)	throws OirsException {
			// Assign new roles to employee by ID
			connection = OirsDbUtil.getConnection();
			PreparedStatement preparedStatement;
			
			try {
				preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_EMP_EMP_TYPE);
				preparedStatement.setString(1, nEmp_type);
				preparedStatement.setString(2, emp_id);
				int ret = preparedStatement.executeUpdate();
				log.info("New Roles assigned");
				return ret;
			} catch (SQLException e) {
				log.error("Error while assigning new roles");
				throw new OirsException("Exception caused while updating EMP_TYPE");
			}
			
		}

		
}
		
