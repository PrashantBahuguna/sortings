/*
 * -------------LoginController------------
 * Made By: Prashant Bahuguna (155251)
 * Created on : 29/08/2018
 * 
 * -->Main Controller of the application, handles all the redirections
 */

package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginController")		//redirection path
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	PrintWriter out=null; 		//For printing into the webpage
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Retrieve the login details
		String name=null;
		String password=null;
		try {
			name = request.getParameter("Name");
			password = request.getParameter("Password");
			if("admin".equals(name) && "admin".equals(password))
			{
				HttpSession session=request.getSession(true);	//Create the session
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
				LocalDateTime now = LocalDateTime.now();  
				//System.out.println(dtf.format(now));  
				
				//Set the values in attributes of the session
				session.setAttribute("Name",name);
				session.setAttribute("Date",dtf.format(now));
				//Redirect to Success.jsp
				RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
				//Forwaring..
				rd.forward(request, response);
			}
			else 
			{
				//If bad details..
				out=response.getWriter();
		  		response.setContentType("text/html");
		  		
		  		out.println("<H3>Please Enter Correct Credentials</H3>");
			}
		} catch (Exception e) {
			System.out.println("Something went wrong.!! Sorry for the incovinience.");
		}
		//Validate the details
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	}

}
