package com.cg.ams.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.ams.entities.TraineeDetails;
import com.cg.ams.dao.JPAUtil;


public class TraineeDetailsDAO implements ITraineeDetailsDAO{

	
	private EntityManager entityManager;

	public TraineeDetailsDAO() 
	{
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void addDetails(TraineeDetails traineeDetails) {		
		entityManager.persist(traineeDetails);		
	}
	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	/*@Override
	public Long getId() {
		
		Long id=0L;
		Query query = entityManager.createNamedQuery("getID");
		@SuppressWarnings("unchecked")
		List<Long> list = query.getResultList();
		id = list.get(0);
		System.err.println("LIST ID : "+id);
		return id;
	}*/

}
