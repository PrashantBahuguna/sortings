package com.cg.ams.dao;

import com.cg.ams.entities.TraineeDetails;

public interface ITraineeDetailsDAO {
	
	public abstract void addDetails(TraineeDetails traineeDetails);

	public abstract void beginTransaction();

	public abstract void commitTransaction();
	
	//public abstract Long getId();

}
