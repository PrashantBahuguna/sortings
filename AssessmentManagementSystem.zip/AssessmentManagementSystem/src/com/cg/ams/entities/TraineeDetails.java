package com.cg.ams.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

//@NamedQueries(@NamedQuery(name = "getID", query = "SELECT val FROM DUAL val"))

@Entity
@Table(name = "trainee_details")
public class TraineeDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private Long details_Id;
	private String trainee_name;
	private String module_name;
	private Integer mpt_marks;
	private Integer mtt_marks;
	private Integer assignment_marks;
	private Integer total;
	
	
	public Long getDetailsId() {
		return details_Id;
	}
	public void setDetailsId(Long detailsId) {
		this.details_Id = detailsId;
	}
	public String getTraineeName() {
		return trainee_name;
	}
	public void setTraineeName(String traineeName) {
		this.trainee_name = traineeName;
	}
	public String getModuleName() {
		return module_name;
	}
	public void setModuleName(String moduleName) {
		this.module_name = moduleName;
	}
	public Integer getMptMarks() {
		return mpt_marks;
	}
	public void setMptMarks(Integer mptMarks) {
		this.mpt_marks = mptMarks;
	}
	public Integer getMttMarks() {
		return mpt_marks;
	}
	public void setMttMarks(Integer mttMarks) {
		this.mpt_marks = mttMarks;
	}
	public Integer getAssignmentMarks() {
		return assignment_marks;
	}
	public void setAssignmentMarks(Integer assignmentMarks) {
		this.assignment_marks = assignmentMarks;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public TraineeDetails(Long detailsId, String traineeName,
			String moduleName, Integer mptMarks, Integer mttMarks,
			Integer assignmentMarks, Integer total) {
		super();
		this.details_Id = detailsId;
		this.trainee_name = traineeName;
		this.module_name = moduleName;
		this.mpt_marks = mptMarks;
		this.mpt_marks = mttMarks;
		this.assignment_marks = assignmentMarks;
		this.total = total;
	}
	public TraineeDetails() {
		super();
	}
	@Override
	public String toString() {
		return "TraineeDetails [detailsId=" + details_Id + ", traineeName="
				+ trainee_name + ", moduleName=" + module_name + ", mptMarks="
				+ mpt_marks + ", mttMarks=" + mpt_marks + ", assignmentMarks="
				+ assignment_marks + ", total=" + total + "]";
	}
	
	
	
}
