package com.cg.ams.ui;

import java.util.Scanner;
import java.util.jar.Attributes.Name;

import com.cg.ams.entities.TraineeDetails;
import com.cg.ams.service.TraineeService;

public class Client {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		TraineeService traineeService = new TraineeService();
		
		TraineeDetails traineeDetails = new TraineeDetails();
		
		System.out.println("********WELCOME TO AMS*********");
		System.out.println("Please provide the following details ");
		System.out.println("Enter Trainee Name : ");
		String name = scanner.next();
		System.out.println("Enter Module Name : ");
		String moduleName = scanner.next();
		System.out.println("Enter MPT Score : ");
		Integer mpt = scanner.nextInt();
		System.out.println("Enter MTT Score : ");
		Integer mtt = scanner.nextInt();
		System.out.println("Enter Assignment Score : ");
		Integer assignment = scanner.nextInt();
		
		//Long id = traineeService.getId();
		//System.err.println("IN main : "+id);
		traineeDetails.setDetailsId(1234L);//Static value can be changed to dynamic using sequence in DB
		traineeDetails.setTraineeName(name);
		traineeDetails.setModuleName(moduleName);
		traineeDetails.setMptMarks(mpt);
		traineeDetails.setMttMarks(mtt);
		traineeDetails.setAssignmentMarks(assignment);
		traineeDetails.setTotal(mpt+mtt+assignment);
		
		traineeService.addDetails(traineeDetails);
		
		System.out.println("Total Marks : "+mpt+mtt+assignment);
		
		
	}

}
