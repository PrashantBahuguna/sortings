package com.cg.ams.service;

import com.cg.ams.dao.TraineeDetailsDAO;
import com.cg.ams.entities.TraineeDetails;


public class TraineeService implements ITraineeService {

	private TraineeDetailsDAO dao;

	public TraineeService() {
		dao = new TraineeDetailsDAO();
	}
	
	@Override
	public void addDetails(TraineeDetails traineeDetails) 
	{
		dao.beginTransaction();
		dao.addDetails(traineeDetails);
		dao.commitTransaction();
	}

	/*@Override
	public Long getId() {
		
		return dao.getId();
		
	}*/
	
}
