package com.cg.ams.service;

import com.cg.ams.entities.TraineeDetails;

public interface ITraineeService {
	
	public abstract void addDetails(TraineeDetails traineeDetails);
	//public abstract Long getId();

}
